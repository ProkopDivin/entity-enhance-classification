import importlib.resources as res
import json
import re
from typing import Any, List, Mapping, Optional, Set, TypeVar

from geneea.core import logutil
from geneea.mediacats.base import Categories, Category, LabelsTranslator, TaxonomyTranslator

LOG = logutil.getLogger(__package__, __file__)

_ID_ONLY = re.compile(r'\s*(\d?\d{7})\s*')
_HRID = re.compile(r'.*\(IPTC-(\d?\d{7})\)\s*')
_TRAILING_ID = re.compile(r'.*\((\d?\d{7})\)\s*')
_MEDTOP = re.compile(r'\s*medtop(?::\s*|_)(\d+)\s*')
_URI = re.compile(r'http://cv.iptc.org/newscodes/mediatopic/(\d+)\s*')


def extractIptcId(label: str) -> Optional[str]:
    """Extract the id from an IPTC label."""
    for pattern in [_ID_ONLY, _HRID, _TRAILING_ID, _MEDTOP, _URI]:
        m = pattern.fullmatch(label)
        if m:
            return m.group(1).zfill(8)

    return None


class IptcTopic(Category):
    def __init__(
            self, *, id: str, fullName: str, path: str, name: str, abbr: Optional[str], superTopics: List['IptcTopic'],
            childTopics: Set['IptcTopic'], level: int, description: str, deprecated: bool,
            replacedBy: Optional['IptcTopic'], wikidataId: Optional[List[str]]
    ) -> None:
        self._id = id
        self._fullName = fullName
        self._path = path
        self._name = name
        self._abbr = abbr
        self._superTopics = superTopics
        self._childTopics = childTopics
        self._level = level
        self._description = description
        self._deprecated = deprecated
        self._replacedBy = replacedBy
        self._wikidataId = wikidataId

    @property
    def id(self) -> str:
        return self._id

    @property
    def fullName(self) -> str:
        return self._fullName

    @property
    def path(self) -> str:
        return self._path

    @property
    def name(self) -> str:
        return self._name

    @property
    def abbr(self) -> Optional[str]:
        return self._abbr

    @property
    def level(self) -> int:
        return self._level

    @property
    def description(self) -> str:
        return self._description

    @property
    def deprecated(self) -> bool:
        return self._deprecated

    @property
    def replacedBy(self) -> Optional['IptcTopic']:
        return self._replacedBy

    @property
    def wikidataId(self) -> Optional[List[str]]:
        return self._wikidataId

    def getTaxonomyId(self) -> str:
        return IptcTopics.TAXONOMY_ID

    def getId(self) -> str:
        return self.id

    def getGkbId(self) -> Optional[str]:
        return f'IPTC-{self.id}'

    def getName(self) -> str:
        return self._name

    def getFullname(self) -> str:
        return self.fullName

    def getAbbreviatedName(self) -> Optional[str]:
        return self._abbr

    def getAncestors(self) -> List['IptcTopic']:
        return list(self._superTopics)

    def getChildren(self) -> Set['IptcTopic']:
        return set(self._childTopics)

    @property
    def medtopId(self) -> str:
        return f'medtop:{self.id}'

    def toCurrent(self) -> Optional['IptcTopic']:
        if self.deprecated:
            newTopic = self.replacedBy
            if newTopic is None:
                LOG.warning(f"Retired topic '{self.fullName}' without a current equivalent")
            else:
                LOG.debug(f"Retired topic: '{self.fullName}' mapped to '{newTopic.fullName}")
            return newTopic
        return self

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, o: object) -> bool:
        return isinstance(o, IptcTopic) and self.id == o.id

    def __str__(self) -> str:
        return f'{self.fullName}'

    def __repr__(self) -> str:
        return f'{self.fullName}'


K = TypeVar('K', bound=Category)


class IptcTopics(Categories[IptcTopic]):
    """Class encapsulating the hierarchy of IPTC topics."""

    TAXONOMY_ID = 'iptc'
    _INSTANCE: 'IptcTopics' = None

    def __init__(self, rawTopics: List[Mapping[str, Any]], keepDescription: bool) -> None:
        self._id2topic = {}
        for rawTopic in rawTopics:
            topicId = rawTopic.get('id')
            replacedById = rawTopic.get('replacedBy')

            topic = IptcTopic(
                id=topicId,
                fullName=rawTopic.get('fullName'),
                name=rawTopic.get('name'),
                path=rawTopic.get('path'),
                abbr=rawTopic.get('abbr'),
                superTopics=[self._id2topic[id] for id in rawTopic.get('superTopics')],
                childTopics=set(),
                level=rawTopic.get('level'),
                description=rawTopic.get('description') if keepDescription else '',
                deprecated=rawTopic.get('deprecated'),
                replacedBy=self._id2topic[replacedById] if replacedById else None,
                wikidataId=rawTopic.get('wikidataId')
            )
            self._id2topic[topic.id] = topic

        for topic in self._id2topic.values():
            if not topic.deprecated and topic.getParent():
                topic.getParent()._childTopics.add(topic)

    @classmethod
    def getInstance(cls) -> 'IptcTopics':
        if cls._INSTANCE is None:
            cls._INSTANCE = cls.load()
        return cls._INSTANCE

    @staticmethod
    def load(keepDescription: bool = True) -> 'IptcTopics':
        with res.open_text(__package__ + '.resources', 'iptc-topics.json', encoding='utf-8') as f:
            return IptcTopics(json.load(f), keepDescription=keepDescription)

    def getTaxonomyId(self) -> str:
        return self.TAXONOMY_ID

    def getCategory(self, topicId: str) -> IptcTopic:
        return self._id2topic[topicId]

    def getCategoryByLabelWithId(self, label: str) -> IptcTopic:
        topicId = extractIptcId(label)
        if not topicId:
            raise ValueError(f"No IPTC id in '{label}' label")
        return self.getCategory(topicId)

    def findCategoryByLabelWithId(self, label: str) -> Optional[IptcTopic]:
        topicId = extractIptcId(label)
        return self._id2topic.get(topicId)

    def getCategoriesByLabelsWithId(self, labels) -> Set[IptcTopic]:
        return {self.getCategoryByLabelWithId(lbl) for lbl in labels}

    def toCurrent(self, topics: Set[IptcTopic]) -> Set[IptcTopic]:
        topics = {t.toCurrent() for t in topics}
        return {t for t in topics if t is not None}

    def getLabelsTranslator(self) -> LabelsTranslator[IptcTopic]:
        raise NotImplementedError('IPTC label translation is not included in the vendored mediacats package')

    def getTaxonomyTranslator(self, target: Categories[K]) -> TaxonomyTranslator[IptcTopic, K]:
        raise ValueError(
            f'Taxonomy translator from "{self.getTaxonomyId()}" to "{target.getTaxonomyId()}" is not available'
        )

    def __iter__(self):
        return iter(self._id2topic.values())
