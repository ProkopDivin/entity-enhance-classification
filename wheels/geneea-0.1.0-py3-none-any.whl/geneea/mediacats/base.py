import abc
import csv
import inspect
from collections import defaultdict
from pathlib import Path
from typing import Callable, Dict, Generic, Iterable, List, Mapping, Optional, Sequence, Set, TextIO, Tuple, TypeVar, Union

from geneea.core import logutil

LOG = logutil.getLogger(__file__, __package__)


class Category(abc.ABC):
    """
    The category or topic within a taxonomy. Each category has an ID unique within the category's taxonomy. Besides
    of the ID it also has several labels or names that provide human-readable identification.
    The categories in a taxonomy are organized to a tree-like hierarchy.
    """
    @abc.abstractmethod
    def getTaxonomyId(self) -> str:
        """Gets this category's taxonomy ID."""
        pass

    @abc.abstractmethod
    def getId(self) -> str:
        """Gets this category's ID which is unique within the category's taxonomy."""
        pass

    def getHrid(self) -> str:
        """
        Gets human-readable ID which is a human-readable string appended with the category's ID.
        The default implementation returns the category's name and ID in parentheses.
        """
        return f'{self.getName()} ({self.getId()})'

    def getGkbId(self) -> Optional[str]:
        """Gets the category's GKB ID, if applicable."""
        return None

    def getGkbHrid(self) -> Optional[str]:
        """
        Gets human-readable ID which is a human-readable string appended with the category's GKB ID.
        The default implementation returns the category's name and GKB ID in parentheses.
        Useful only when getGkbId() is overridden and returns actual GKB ids.
        """
        return f'{self.getName()} ({self.getGkbId()})'

    @abc.abstractmethod
    def getName(self) -> str:
        """Gets the category's name which is a simple human-readable name of the category."""
        pass

    @abc.abstractmethod
    def getFullname(self) -> str:
        """
        Gets the category's full name. The full name identifies the category and its position within the tree-like
        taxonomy structure and also contains the category's ID.
        """
        pass

    @abc.abstractmethod
    def getAbbreviatedName(self) -> Optional[str]:
        """
        Gets the abbreviated or short variant of the category's name. Many categories do not have an abbreviated name.
        """
        pass

    def getLongName(self, withId: bool = True, abbreviate: bool = False, shorten: bool = False) -> str:
        """
        Returns a name of this category containing all or some of its parent category names.

        Examples:
        - `lifestyle and leisure > leisure > hobby > food and drink enthusiasm > cooking and baking (20001253)`
        - `lifestyle and leisure > leisure > hobby > food and drink enthusiasm > cooking and baking`
        - `lifestyle and leisure >>>> cooking and baking (20001253)`
        - `lifestyle+ > leisure > hobby > food and drink enthusiasm > cooking and baking (20001253)`
        - `lifestyle+ >>>> cooking and baking (20001253)`

        :param withId: should the category ID be included in parentheses as a suffix of the returned string
        :param abbreviate: abbreviate category names (if possible)
        :param shorten: only include the top and most specific category names, omitting everything in between,
           with arrows indicating the level of nesting
        :return: the category name
        """
        def _abbrOrName(t: Category):
            return t.getAbbreviatedName() or t.getName() if abbreviate else t.getName()

        if not abbreviate and not shorten and withId:
            return self.getFullname()

        else:
            if self.getAncestors():
                if shorten:
                    top = _abbrOrName(self.getAncestors()[0])
                    separator = '>' * (len(self.getAncestors()))
                    prefix = f'{top} {separator} '
                else:
                    prefix = ' > '.join(_abbrOrName(t) for t in self.getAncestors()) + ' > '
            else:
                prefix = ''

            result = f'{prefix}{_abbrOrName(self)}'

            if abbreviate and self.getAbbreviatedName():
                result += f' - {self.getName()}'

            if withId:
                result += f' ({self.getId()})'

        return result

    @abc.abstractmethod
    def getAncestors(self) -> List['C']:
        """
        Gets all parent categories (ancestors) ordered from the most general category (ie. the root
        or top level category) to the immediate parent of this category.
        """
        pass

    @abc.abstractmethod
    def getChildren(self) -> Set['C']:
        """
        Gets all child categories of this category (ie. categories that have this category as their immediate parent).
        """
        pass

    def getDescendants(self) -> Set['C']:
        """
        Gets all transitive children (descendants) of this category (ie. the immediate children of this category
        and all its transitive children).
        """
        return self.getChildren() | {cc for c in self.getChildren() for cc in c.getDescendants()}

    def getPath(self) -> List['C']:
        """
        Gets the complete path of categories from the top level category to this category. It's the same list returned
        from `getAncestors()` appended with this category itself.
        """
        return self.getAncestors() + [self]

    def getParent(self) -> Optional['C']:
        """
        Gets the immediate parent category of this category or None for the top level categories that have no parent.
        """
        if self.getAncestors():
            return self.getAncestors()[-1]


C = TypeVar('C', bound=Category)
K = TypeVar('K', bound=Category)


class LabelsTranslator(abc.ABC, Generic[C]):
    """
    Translates labels to categories from a certain taxonomy. The translators help map the annotation labels
    that may have no IDs or contain typos to the taxonomy categories.
    """
    @abc.abstractmethod
    def findCategoryByLabel(self, label: str) -> Optional[C]:
        """
        Gets a taxonomy category for a label or None if the label cannot be mapped to any of the taxonomy categories.
        """
        pass

    def findCategoriesByLabels(self, labels: Iterable[str]) -> Set[C]:
        """Gets all taxonomy categories that a set of labels can be mapped to."""
        categories = {self.findCategoryByLabel(t) for t in labels}
        return {c for c in categories if c}


class TaxonomyTranslator(abc.ABC, Generic[C, K]):
    """
    Translates categories from a certain taxonomy to another taxonomy.
    """
    @abc.abstractmethod
    def translateCategory(self, category: C) -> Set[K]:
        """
        Gets a category from another taxonomy for a given category or an empty set if the category cannot be mapped to
        any of the taxonomy categories.
        """
        pass

    def translateCategories(self, categories: Iterable[C]) -> Set[K]:
        """Gets all categories from another taxonomy that a set of categories can be mapped to."""
        translatedCats = set()
        for c in categories:
            translatedCats.update(self.translateCategory(c))
        return translatedCats


class Categories(abc.ABC, Generic[C]):
    """
    This is a taxonomy base class. It's a container for all the categories that belong to the taxonomy.
    """
    @abc.abstractmethod
    def getTaxonomyId(self) -> str:
        """Gets this taxonomy ID."""
        pass

    @abc.abstractmethod
    def getCategory(self, catId: str) -> C:
        """
        Gets a category by its ID.

        :raises KeyError: for unknown ids.
        """
        pass

    @abc.abstractmethod
    def getCategoryByLabelWithId(self, label: str) -> C:
        """
        Gets a category by extracting its ID from the label passed in.

        :raises ValueError: for labels without ids.
        :raises KeyError: for labels with unknown ids.
        """
        pass

    @abc.abstractmethod
    def findCategoryByLabelWithId(self, label: str) -> Optional[C]:
        """
        Gets a category by extracting its ID from the label or None if the label contains no ID or no category exists
        for the extracted ID.
        """
        pass

    def getCategoriesByLabelsWithId(self, labels: Iterable[str]) -> Set[C]:
        """ Maps a set of category labels with id number to categories (see getCategoryByLabelWithId).

        :raises ValueError: if any label contains no id.
        :raises KeyError: if any label has an unknown id.
        """
        return {self.getCategoryByLabelWithId(lbl) for lbl in labels}

    def normalizeCategories(self, categories: Iterable[C], *, keepDeprecated: bool = False) -> Set[C]:
        """
        Normalizes categories by updating all deprecated categories whenever possible and adding all super categories.
        This relies on the `toCurrent()` function to (optionally) remove and replace (if possible) all deprecated categories.
        """
        inputCategories = set(categories)
        currentCategories = self.toCurrent(inputCategories)
        # super categories of current categories are always current
        currentCategories = self.addAncestors(currentCategories)
        if keepDeprecated:
            return currentCategories | set(inputCategories) | self.addAncestors(inputCategories)
        else:
            return currentCategories

    def normalizeCategoriesWeighted(self, weightedCategories: Iterable[Tuple[C, float]], *, keepDeprecated: bool = False) -> Mapping[C, float]:
        """
        Normalizes categories by updating all deprecated categories whenever possible and adding all super categories.
        This relies on the `toCurrent()` function to (optionally) remove and replace (if possible) all deprecated categories.
        The final weights are computed as a maximum for each category, where the weight of a child category
        propagates to all its super categories.
        """
        catWeights = defaultdict(list)
        for cat, weight in weightedCategories:
            current = self.toCurrent({cat})
            if not current:
                if keepDeprecated:
                    for c in cat.getPath():
                        catWeights[c].append(weight)
                continue
            currentCat = next(iter(current))
            for c in currentCat.getPath():
                catWeights[c].append(weight)
            if keepDeprecated and currentCat != cat:
                for c in cat.getPath():
                    catWeights[c].append(weight)
        return {cat: max(weights) for cat, weights in catWeights.items()}

    @abc.abstractmethod
    def toCurrent(self, categories: Set[C]) -> Set[C]:
        """
        Updates all deprecated categories whenever possible.

        Removes all deprecated categories and replaces them by their new variants if that's possible.
        Categories without a replacement are removed from the result. Categories with more than one replacement
        are replaced by the most specific super categories of these replacements.
        """
        pass

    def addAncestors(self, categories: Set[C]) -> Set[C]:
        """
        Adds all transitive parent categories (ancestors) of the categories passed in.

        :param categories: set of categories that should have their super categories added
        :return: new set of categories that includes the original categories and all their super categories
        """
        return categories | {tt for t in categories for tt in t.getAncestors()}

    def removeAncestors(self, categories: Set[C]) -> Set[C]:
        """
        Keeps only the most specific categories.

        :param categories: set of categories that should have their transitive parent categories (ancestors) removed
        :return: the subset of the original categories that contains no super categories of any of its categories
        """
        return {c for c in categories if not any(c in cc.getAncestors() for cc in categories)}

    @abc.abstractmethod
    def getLabelsTranslator(self) -> LabelsTranslator[C]:
        """
        Gets the default labels translator instance. The returned instance should be capable of translating
        all variants of english labels/names (simple, short, abbreviated, full, etc) to categories.
        """
        pass

    @abc.abstractmethod
    def getTaxonomyTranslator(self, target: 'Categories[K]') -> TaxonomyTranslator[C, K]:
        """
        Gets the default taxonomy translator instance. The returned instance should be capable of translating
        categories from the source taxonomy (self) to categories from the target taxonomy. `ValueError` is raised
        if there is no implementation for a given taxonomy pair.
        """
        pass

    @abc.abstractmethod
    def __iter__(self):
        """Gets an iterator over all categories in this taxonomy."""
        pass


class Taxonomies:
    """
    This is the registry of the taxonomies (`Categories` implementations). The taxonomy implementations can use its
    `register()` and `unregister()` functions for registering factories that create `Categories` implementations. Each
    factory is registered under the unique ID of the taxonomy which instance it creates.
    """
    _INSTANCE = None

    @staticmethod
    def getInstance() -> 'Taxonomies':
        if not Taxonomies._INSTANCE:
            Taxonomies._INSTANCE = Taxonomies()
        return Taxonomies._INSTANCE

    def __init__(self) -> None:
        self._factories: Dict[str, Callable[Union[[], [str]], Categories]] = {}

    def getById(self, taxonomyId: str) -> Categories:
        """
        Gets a taxonomy for its ID.

        :raises KeyError: for unknown ids.
        """
        factory = self._factories[taxonomyId]
        param = inspect.signature(factory).parameters.get('taxonomyId')
        if param:
            taxonomy = factory(taxonomyId=taxonomyId)
        else:
            taxonomy = factory()
        if not isinstance(taxonomy, Categories):
            raise Exception(f'The factory {factory} for "{taxonomyId}" taxonomy returned invalid instance: {taxonomy}')
        return taxonomy

    def getAllIds(self) -> List[str]:
        """
        Gets IDs of all the registered taxonomies.
        """
        return list(self._factories.keys())

    def register(self, taxonomyId: str, factory: Callable[[], Categories]):
        """
        Registers a taxonomy implementation factory (ie. a callable that returns `Categories` instance)
        under the taxonomy ID.

        :raises ValueError: for missing taxonomyId or factory parameters
        """
        if not taxonomyId:
            raise ValueError('No taxonomy ID')
        if not factory:
            raise ValueError('No taxonomy')
        self._factories[taxonomyId] = factory

    def unregister(self, taxonomyId):
        """
        Removes the factory registered under `taxonomyId`.
        """
        if not taxonomyId:
            raise ValueError('No taxonomy ID')
        self._factories.pop(taxonomyId, None)


class ProxyLabelsTranslator(LabelsTranslator[C]):
    """
    A helper class that implements `LabelsTranslator` interface and delegates to multiple other `LabelsTranslator`
    implementations. The first delegate that returns a `Category` wins.
    """
    def __init__(self, delegates: Sequence[LabelsTranslator[C]]) -> None:
        self._delegates = list(delegates)

    def findCategoryByLabel(self, label: str) -> Optional[C]:
        for t in self._delegates:
            category: Optional[C] = t.findCategoryByLabel(label)
            if category:
                return category

        return None


class MapLabelsTranslator(LabelsTranslator[C]):
    """
    A simple dictionary-based `LabelsTranslator` implementation. The mapping can be read from a CSV file or supplied
    directly via the constructor.
    """
    def __init__(self, mapping: Mapping[str, C]) -> None:
        self._mapping = dict(mapping)

    def findCategoryByLabel(self, label: str) -> Optional[C]:
        return self._mapping.get(label)

    @staticmethod
    def fromCsvFile(
            inputFile: Path, *, labelCol: str, categoryCol: str, taxonomy: Categories[C]
    ) -> 'MapLabelsTranslator':
        with inputFile.open(mode='r', encoding='utf-8') as f:
            mapping: Dict[str, C] = {}
            for row in csv.DictReader(f):
                label = row[labelCol]
                category = taxonomy.findCategoryByLabelWithId(row[categoryCol])
                if category:
                    mapping[label] = category
                else:
                    LOG.warning(f'Category not found: {row[categoryCol]}')

            return MapLabelsTranslator(mapping)


class MapTaxonomyTranslator(TaxonomyTranslator[C, K]):
    """
    A simple dictionary-based `TaxonomyTranslator` implementation. The mapping can be read from a CSV file or supplied
    directly via the constructor.
    """
    def __init__(self, mapping: Iterable[Tuple[C, Iterable[K]]]) -> None:
        self._mapping = {c: frozenset(ks) for c, ks in mapping}

    def translateCategory(self, category: C) -> Set[K]:
        return self._mapping.get(category, set())

    @staticmethod
    def fromCsvFile(
            inputFile: TextIO, *, sourceCatCol: str = 'fromCat', targetCatCol: str = 'toCat', source: Categories[C], target: Categories[K]
    ) -> 'MapTaxonomyTranslator':
        """
        Create an instance of `MapTaxonomyTranslator` with mapping loaded from a csv file
        :param inputFile: input csv with mapping of categories between two taxonomies
        :param sourceCatCol: name of a column with source categories, default: "fromCat"
        :param targetCatCol: name of a column with target categories, default: "toCat"
        :param source: source taxonomy
        :param target: target taxonomy
        :return: instance of `MapTaxonomyTranslator` with mapping loaded from a csv file
        """
        mapping: Dict[C, Set[K]] = defaultdict(set)
        for row in csv.DictReader(inputFile):
            sourceCategory = source.findCategoryByLabelWithId(row[sourceCatCol])
            targetCategory = target.findCategoryByLabelWithId(row[targetCatCol])
            if sourceCategory and targetCategory:
                mapping[sourceCategory].add(targetCategory)
            else:
                if not sourceCategory:
                    LOG.warning(f'Category not found: {row[sourceCatCol]} in taxonomy "{source.getTaxonomyId()}"')
                if not targetCategory:
                    LOG.warning(f'Category not found: {row[targetCatCol]} in taxonomy "{target.getTaxonomyId()}"')

        return MapTaxonomyTranslator(mapping.items())
