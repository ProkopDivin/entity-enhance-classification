# coding=utf-8

from collections import Counter, defaultdict
from itertools import groupby
from operator import attrgetter, itemgetter
from typing import Any, Callable, Hashable, Iterable, List, Mapping, NamedTuple, Set, Tuple, TypeVar, Union

import regex as re

from geneea.core import logutil

LOG = logutil.getLogger(__package__, __file__)

WS_RE = re.compile(r'\s+')

Num = Union[int, float]
U = TypeVar('U')
V = TypeVar('V')
T_Ha = TypeVar('T_Ha', bound=Hashable)  # type variable for hashable types, usually types used as dict keys
ConfusionMatrix = Mapping[T_Ha, Mapping[T_Ha, Num]]


def divOrZero(dividend: Num, divisor: Num) -> float:
    """
    @return: dividend / divisor if divisor is non-zero, 0.0 otherwise
    """
    return dividend / divisor if divisor else 0.0


def ratioStr(ratio: float, dividend: Num=None, divisor: Num=None) -> str:
    """
    @return: Ratio as a percentage string, optionally accompanied with dividend and divisor,
    for example '60% (3/5)'
    """
    result = f'{ratio:.2%}'
    if dividend is not None and divisor is not None:
        result += f' ({dividend}/{divisor})'
    return result


def fmeasure(precision: float, recall: float, beta: float=1.0) -> float:
    """
    @param precision: precision
    @param recall: recall
    @param beta: beta; higher the beta, higher the importance of recall
    @return: F-measure for given parameters
    """
    betaSq = beta ** 2
    return divOrZero(
        (1 + betaSq) * precision * recall,
        betaSq * precision + recall
    )


class ClassData:
    """
    Helper class for computing classification precision and recall.
    """

    def __init__(self, trueCnt: int=0, predCnt: int=0, correctCnt: int=0) -> None:
        self.trueCnt = trueCnt
        self.predCnt = predCnt
        self.correctCnt = correctCnt

    @staticmethod
    def empty() -> 'ClassData':
        return ClassData(0, 0, 0)

    @staticmethod
    def aggregate(classDataValues: Iterable['ClassData']) -> 'ClassData':
        classData = ClassData.empty()
        for val in classDataValues:
            classData.update(val.trueCnt, val.predCnt, val.correctCnt)
        return classData

    def incTrue(self, value: int=1) -> 'ClassData':
        self.trueCnt += value
        return self

    def incPred(self, value: int=1) -> 'ClassData':
        self.predCnt += value
        return self

    def incCorr(self, value: int=1) -> 'ClassData':
        self.correctCnt += value
        return self

    def update(self, sumTrue: int, sumPred: int, sumCorr: int) -> 'ClassData':
        self.incTrue(sumTrue)
        self.incPred(sumPred)
        self.incCorr(sumCorr)
        return self

    def fmeasure(self, beta: float=1.0) -> float:
        return fmeasure(self.precision, self.recall, beta=beta)

    @property
    def precision(self) -> float:
        return divOrZero(self.correctCnt, self.predCnt)

    @property
    def recall(self) -> float:
        return divOrZero(self.correctCnt, self.trueCnt)

    @property
    def f1(self) -> float:
        return self.fmeasure()

    def infoStr(self, className: str=None) -> str:
        className = className + ' ' if className else ''
        precStr = f'{className}precision: {ratioStr(self.precision, dividend=self.correctCnt, divisor=self.predCnt)}'
        recStr = f'{className}recall: {ratioStr(self.recall, dividend=self.correctCnt, divisor=self.trueCnt)}'
        return '\n'.join((precStr, recStr))

    def asTuple(self) -> Tuple[int, int, int]:
        return self.trueCnt, self.predCnt, self.correctCnt

    def __eq__(self, o: object) -> bool:
        return isinstance(o, ClassData) and self.asTuple() == o.asTuple()

    def __hash__(self) -> int:
        return hash(self.asTuple())

    def __str__(self) -> str:
        return f'ClassData{self.asTuple()}'

    def __repr__(self) -> str:
        return f'ClassData{self.asTuple()}'


class AvgData:
    """
    Helper class for computing average precision and recall. That is useful particularly for multi-label
    label classification where each data point can have multiple correct labels. Averaging
    is done so that each data point has the same influence on the final result.
    """

    def __init__(self, sumPrecision: float=0, sumRecall: float=0, dataCnt: int=0) -> None:
        self.sumPrecision = sumPrecision
        self.sumRecall = sumRecall
        self.cnt = dataCnt

    @staticmethod
    def empty() -> 'AvgData':
        return AvgData(0, 0, 0)

    @staticmethod
    def aggregate(avgDataValues: Iterable['AvgData']) -> 'AvgData':
        avgData = AvgData.empty()
        for val in avgDataValues:
            avgData.update(val.sumPrecision, val.sumRecall, val.cnt)
        return avgData

    def incPrecSum(self, value: float=1.0) -> 'AvgData':
        self.sumPrecision += value
        return self

    def incRecallSum(self, value: float=1.0) -> 'AvgData':
        self.sumRecall += value
        return self

    def incDataCnt(self, value: int=1) -> 'AvgData':
        self.cnt += value
        return self

    def update(self, prec: float, recall: float, cnt: int=1) -> 'AvgData':
        self.incPrecSum(prec)
        self.incRecallSum(recall)
        self.incDataCnt(cnt)
        return self

    def fmeasure(self, beta: float=1.0) -> float:
        """
        @return: F-measure based on average precision and recall
        """
        return fmeasure(self.precision, self.recall, beta=beta)

    @property
    def precision(self) -> float:
        return divOrZero(self.sumPrecision, self.cnt)

    @property
    def recall(self) -> float:
        return divOrZero(self.sumRecall, self.cnt)

    @property
    def f1(self) -> float:
        return self.fmeasure()

    def infoStr(self) -> str:
        precStr = f'Average precision: {self.precision:.2%}'
        recStr = f'Average recall: {self.recall:.2%}'
        cntStr = f'Data count: {self.cnt}'
        return '\n'.join((precStr, recStr, cntStr))

    def asTuple(self) -> Tuple[float, float, int]:
        return self.sumPrecision, self.sumRecall, self.cnt

    def __eq__(self, o: object) -> bool:
        return isinstance(o, AvgData) and self.asTuple() == o.asTuple()

    def __hash__(self) -> int:
        return hash(self.asTuple())

    def __str__(self) -> str:
        return f'AvgData{self.asTuple()}'

    def __repr__(self) -> str:
        return f'AvgData{self.asTuple()}'


def accuracy(
        trueVals: Iterable[U],
        predVals: Iterable[V],
        *,
        trueValKey: Callable[[U], T_Ha]=lambda x: x,
        predValKey: Callable[[V], T_Ha]=lambda x: x,
) -> Tuple[float, int, int]:
    """
    Compute accuracy of given prediction
    @param trueVals: iterable of 'true' values
    @param predVals: iterable of predicted values
    @param trueValKey: function (item of trueVals) -> value to be compared against a prediction
    @param predValKey: function (item of predVals) -> value to be compared against the true value
    @return: tuple accuracy, correct count, total count
    """
    totalCnt = 0
    correctCnt = 0
    for trueVal, predVal in zip(trueVals, predVals):
        totalCnt += 1
        if trueValKey(trueVal) == predValKey(predVal):
            correctCnt += 1

    return divOrZero(correctCnt, totalCnt), correctCnt, totalCnt


def classStats(
        trueVals: Iterable[U],
        predVals: Iterable[V],
        *,
        trueValKey: Callable[[U], T_Ha]=lambda x: x,
        predValKey: Callable[[V], T_Ha]=lambda x: x,
) -> Tuple[Mapping[T_Ha, ClassData], ClassData, ConfusionMatrix]:
    """
    Compute precision and recall of given classification. Both total and for individual classes.
    @param trueVals: iterable of 'true' values
    @param predVals: iterable of predicted values
    @param trueValKey: function (item of trueVals) -> value to be compared against a prediction
    @param predValKey: function (item of predVals) -> value to be compared against the true value
    @return: tuple (class stats, total stats, confusion matrix).
        class stats is a map class label -> ClassData,
        total stats is a ClassData instance,
        confusion matrix is a sparse matrix where C[i, j] = number of observations known to be in group i
             and predicted to be in group j.
    """
    cnfMatrix = defaultdict(Counter)
    classToData = defaultdict(ClassData.empty)

    for trueVal, predVal in zip(trueVals, predVals):
        trueClass = trueValKey(trueVal)
        predClass = predValKey(predVal)

        classToData[trueClass].incTrue()
        classToData[predClass].incPred()

        if trueClass == predClass:
            classToData[trueClass].incCorr()

        cnfMatrix[trueClass][predClass] += 1

    return classToData, ClassData.aggregate(classToData.values()), cnfMatrix


def multiStats(
        goldVals: Iterable[Iterable[U]],
        predVals: Iterable[Iterable[V]],
        *,
        goldValKey: Callable[[U], T_Ha]=lambda x: x,
        predValKey: Callable[[V], T_Ha]=lambda x: x,
) -> Tuple[AvgData, ClassData, Mapping[T_Ha, ClassData]]:
    """
    Compute stats for multi-label classification
    @param goldVals: iterable of gold label sets
    @param predVals: iterable of predicted label set
    @param goldValKey: function (gold label) -> value to be compared against predictions
    @param predValKey: function (predicted label) -> value to be compared against gold values
    @return: tuple:
            stats with average precision/recall (AvgData)
            stats (ClassData) with unweighted precision/recall (data points with more labels will have higher influence)
            map (label) ->  stats (ClassData)
    """

    avgStats = AvgData.empty()
    classToData = defaultdict(ClassData.empty)

    for locGold, locPred in zip(goldVals, predVals):
        locGold = set(map(goldValKey, locGold))
        locPred = set(map(predValKey, locPred))
        locCorr = locGold & locPred

        for label in locGold:
            classToData[label].incTrue()
        for label in locPred:
            classToData[label].incPred()
        for label in locCorr:
            classToData[label].incCorr()

        locStats = ClassData(trueCnt=len(locGold), predCnt=len(locPred), correctCnt=len(locCorr))
        avgStats.update(prec=locStats.precision, recall=locStats.recall)

    return avgStats, ClassData.aggregate(classToData.values()), classToData


def transpose(matrix: ConfusionMatrix) -> ConfusionMatrix:
    """
    Transpose a sparse matrix
    @param matrix: input sparse matrix
    @return: transposed sparse matrix
    """
    tmatrix = defaultdict(Counter)

    for i, srow in matrix.items():
        for j, val in srow.items():
            tmatrix[j][i] += val

    return tmatrix


def junitTestCase2str(testCase: 'junit_xml.TestCase') -> str:
    if testCase.is_error():
        return f'Test {testCase.name} ... ERROR: {testCase.error_message}'
    elif testCase.is_failure():
        return f'Test {testCase.name} ... FAILED: {testCase.failure_message}'
    elif testCase.is_skipped():
        return f'Test {testCase.name} ... SKIPPED: {testCase.skipped_message}'
    else:
        return f'Test {testCase.name} ... OK'
