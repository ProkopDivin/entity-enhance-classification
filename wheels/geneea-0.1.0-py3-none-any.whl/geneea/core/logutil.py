# coding=utf-8

import json
import logging
import logging.config
import os
import sys
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Union
from urllib.parse import urlparse

import yaml

try:
    import pygelf
except ImportError:
    pygelf = None


class Event(Enum):
    """
    An event log type.
    """
    INFO = 0
    START = 1
    PROGRESS = 2
    FINISH = 3
    FAILURE = 4

    @property
    def logLevel(self) -> int:
        """
        @return: logging level for this event
        """
        return logging.INFO if self != Event.FAILURE else logging.ERROR


class EventLogger:
    """
    A wrapper of the standard Logger for event logging.
    """

    def __init__(self, LOG: Union[logging.Logger, str]):
        """
        @param LOG: a Logger or a name string
        """
        if not LOG:
            LOG = logging.getLogger()
        elif isinstance(LOG, str):
            LOG = logging.getLogger(LOG)
        elif not isinstance(LOG, logging.Logger):
            raise TypeError('LOG must be Logger or a name string')
        self._LOG = LOG

    def emit(self, event: Event, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with given event and its message.
        @param event: the event type
        @param message: the event log message
        @param task: optional name of the executed task
        @param kwargs: additional kwargs used in 'extra' param
        """
        extra = self._extraOf(event, task, **kwargs)
        self._LOG.log(event.logLevel, message, extra=extra)

    def info(self, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with INFO event and its message.
        """
        self.emit(Event.INFO, message, task=task, **kwargs)

    def start(self, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with START event and its message.
        """
        self.emit(Event.START, message, task=task, **kwargs)

    def progress(self, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with PROGRESS event and its message.
        """
        self.emit(Event.PROGRESS, message, task=task, **kwargs)

    def finish(self, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with FINISH event and its message.
        """
        self.emit(Event.FINISH, message, task=task, **kwargs)

    def failure(self, message: str, *, task: str = None, **kwargs):
        """
        Calls the logger with FAILURE event and its message.
        """
        self.emit(Event.FAILURE, message, task=task, **kwargs)

    def _extraOf(self, event: Event, task: str = None, **kwargs) -> Dict[str, Any]:
        extra = {
            'log_event': event
        }
        if task:
            extra['event_task'] = task
        if kwargs:
            extra.update(kwargs)
        return extra

    @staticmethod
    def getEvent(record: logging.LogRecord) -> Optional[Event]:
        """
        Extracts an event from the given log record, if it is an event log.
        """
        return getattr(record, 'log_event', None)

    @staticmethod
    def getTask(record: logging.LogRecord) -> Optional[str]:
        """
        Extracts a task name from the given log record, if it is an event log.
        """
        return getattr(record, 'event_task', None)


def addLogArguments(parser, **kwargs):
    """
    Adds --log-config argument for specifying a path to a file with the logging configuration.
    @param parser: The argument parser (argparser) to configure.
    @return: The parser passed in.
    """
    group = parser.add_argument_group('Logging options')
    group.add_argument('--log-config', dest='logConfigFile', type=str, default=None, metavar='<path>',
                       help='path to *.yaml or *.ini file with logging configuration,'
                            ' if specified all other options are ignored',
                       **kwargs)
    group.add_argument('--log-file', dest='logFile', type=str, default=None, metavar='<path>',
        help='path to a log file that will be attached to the root logger', **kwargs)
    group.add_argument('--log-level', dest='logLevel', type=str, choices=['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL'],
                       default=None,
        help='logging level', **kwargs)
    group.add_argument('--log-stdout', dest='logStdout', action='store_true',
        help='send log messages to stdout if --log-file is not specified; otherwise log to stderr', **kwargs)
    group.add_argument('--log-gelf-tls', dest='logGelfTls', type=str, default=None, metavar='<url>',
                       help='url to a graylog server (eg. http://log.geneea.com:12221),'
                            ' creates GELF TLS handler for the root logger',
                       **kwargs)
    group.add_argument('--log-gelf-tcp', dest='logGelfTcp', type=str, default=None, metavar='<url>',
                       help='url to a graylog server (eg. http://log.geneea.com:12221),'
                            ' creates GELF TCP handler for the root logger',
                       **kwargs)
    group.add_argument('--log-gelf-options', dest='logGelfOptions', type=json.loads, default=None, metavar='<json>',
                       help='GELF handler extra options (eg. \'{"_appname": "Geneea Analyzer"}\'',
                       **kwargs)
    return parser


def configureFromArgs(args: Any = None):
    """
    Configures logging framework from command-line arguments.
    @param args: Any object which can be converted to a dictionary and supplies keyword arguments of
        the :method:`configure()` method.
    """
    if isinstance(args, Mapping):
        configure(**args)

    elif hasattr(args, '_asdict'):
        configure(**args._asdict())

    elif args is not None:
        configure(
            logConfigFile=args.logConfigFile,
            logFile=args.logFile,
            logLevel=args.logLevel,
            logStdout=args.logStdout,
            logGelfTls=args.logGelfTls,
            logGelfTcp=args.logGelfTcp,
            logGelfOptions=args.logGelfOptions
        )

    else:
        configure()


def configure(*, logConfigFile: str = None, logFile: str = None, logLevel: str = None, logStdout: bool = False,
              logGelfTls: str = None, logGelfTcp: str = None, logGelfOptions: dict = None, **kwargs):
    """
    Configures logging framework.
    @param logConfigFile: Path to a config file. The logging configuration can either be stored in *.yaml or *.ini
        file. Please read https://docs.python.org/3/library/logging.config.html for details.
    """
    if logConfigFile:
        ext = logConfigFile.rsplit('.', maxsplit=1)
        if len(ext) == 2 and ext[1] == 'yaml':
            with open(logConfigFile, 'r', encoding='utf-8') as f:
                cfg = yaml.safe_load(f)
            cfg['version'] = 1
            cfg['disable_existing_loggers'] = False
            logging.config.dictConfig(cfg)
        else:
            logging.config.fileConfig(logConfigFile, disable_existing_loggers=False)
    else:
        _defaultConfig(logFile=logFile, logLevel=logLevel, logStdout=logStdout,
                       logGelfTls=logGelfTls, logGelfTcp=logGelfTcp, logGelfOptions=logGelfOptions)


class BraceMessage(object):
    def __init__(self, fmt, *args, **kwargs):
        self.fmt = fmt
        self.args = args
        self.kwargs = kwargs

    def __str__(self):
        return self.fmt.format(*self.args, **self.kwargs)


class DollarMessage(object):
    def __init__(self, fmt, **kwargs):
        self.fmt = fmt
        self.kwargs = kwargs

    def __str__(self):
        from string import Template
        return Template(self.fmt).substitute(**self.kwargs)


def _defaultConfig(*, logFile: str = None, logLevel: str = None, logStdout: bool = False,
                   logGelfTls: str = None, logGelfTcp: str = None, logGelfOptions: dict = None):
    fmt = '%(asctime)s %(levelname)s [%(name)s]: %(message)s'
    datefmt = '%Y-%m-%d %H:%M:%S'
    rootLevel = logLevel if logLevel else logging.INFO
    if logFile:
        logging.basicConfig(format=fmt, datefmt=datefmt, level=rootLevel, filename=logFile)
    else:
        logStream = sys.stdout if logStdout else sys.stderr
        logging.basicConfig(format='%(message)s', level=rootLevel, stream=logStream)

    if logGelfTls:
        handler = _gelfHandler(logGelfTls, logGelfOptions, tls=True)
        handler.setFormatter(logging.Formatter(fmt))
        handler.addFilter(_AddLoggerNameFilter())
        logging.getLogger().addHandler(handler)
    elif logGelfTcp:
        handler = _gelfHandler(logGelfTcp, logGelfOptions, tls=False)
        handler.setFormatter(logging.Formatter(fmt))
        handler.addFilter(_AddLoggerNameFilter())
        logging.getLogger().addHandler(handler)

    logger = logging.getLogger('geneea')
    logger.setLevel(logging.NOTSET if logLevel else logging.DEBUG)
    logger.propagate = 1


def _gelfHandler(serverUrl: str, options: dict = None, tls: bool = False):
    if pygelf is None:
        raise ImportError('pygelf is required for GELF logging; install with: pip install pygelf')
    url = urlparse(serverUrl)
    options = dict(options) if options else dict()
    if tls:
        return pygelf.GelfTlsHandler(host=url.hostname, port=url.port, include_extra_fields=True, **options)
    return pygelf.GelfTcpHandler(host=url.hostname, port=url.port, include_extra_fields=True, **options)


class _AddLoggerNameFilter(logging.Filter):
    def filter(self, record):
        record.loggerName = record.name
        return True


def getLogger(package: Optional[str], file: Optional[str]) -> logging.Logger:
    """
    Gets a Logger object with its name set to the fully-qualified name of a python module.

    Example: LOG = logutil.getLogger(__package__, __file__)

    @param package: module's package
    @param file: module's file path
    @return: `logging.Logger` instance
    """
    if package and file:
        return logging.getLogger('.'.join([package, os.path.splitext(os.path.basename(file))[0]]))
    elif file:
        return logging.getLogger(os.path.splitext(os.path.basename(file))[0])
    else:
        return logging.getLogger()
