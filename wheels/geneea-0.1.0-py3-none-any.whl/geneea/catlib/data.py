"""
Tools for working with data used for categorization.
"""

import csv
import itertools
import json

from collections import Counter
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, NamedTuple, Sequence, TextIO, Tuple, Union

from geneea.core import logutil


LOG = logutil.getLogger(__package__, __file__)


class Doc(NamedTuple):
    """
    Text document + categories and metadata
    """
    id: str
    title: str
    lead: str
    text: str
    cats: List[str]
    metadata: Dict[str, Any]

    @classmethod
    def of(cls, *,
            id: str = None,
            title: str = None,
            lead: str = None,
            text: str,
            cats: List[str] = None,
            metadata: Dict[str, Any] = None
    ) -> 'Doc':
        return cls(id, title or '', lead or '', text, cats or [], metadata or {})

    @classmethod
    def fromDict(cls, d) -> 'Doc':
        return cls(
            id=d['id'],
            title=d.get('title', ''),
            lead=d.get('lead', ''),
            text=d['text'],
            cats=sorted(set(d['cats'].split('|'))) if d.get('cats') else [],
            metadata=json.loads(d.get('metadata') or '{}')
        )

    def toCsvRowDict(self) -> Dict:
        """
        :return: dictionary used as a row for `csv.DictWriter`
        """
        return {
            'id': self.id,
            'title': self.title,
            'lead': self.lead,
            'text': self.text,
            'cats': '|'.join(sorted(self.cats)),
            'metadata': json.dumps(self.metadata) if self.metadata else ''
        }

    @property
    def allText(self) -> str:
        """
        :return: complete document text composed of title, lead and body joined by double newline
        """
        return '\n\n'.join((self.title, self.lead, self.text))


class Corpus:
    """
    Corpus consisting of categorized documents (represented as Doc instances)
    """
    def __init__(self, docs: Iterable[Doc]) -> None:
        self.docs = list(docs)
        self.catCounts = Counter(c for d in self.docs for c in d.cats)
        self.catList = sorted(self.catCounts.keys())
        self.catToIdx = {c: i for i, c in enumerate(self.catList)}

    @classmethod
    def fromCsv(cls, filePath: Union[str, Path]) -> 'Corpus':
        """
        Read corpus from CSV with columns
        1. id
        2. title (optional)
        3. lead (optional)
        4. text
        5. cats (pipe delimited categories)
        6. metadata (optional, JSON encoded)
        :param filePath: input file path
        :return: corpus loaded from the file
        """
        with open(filePath, encoding='utf-8') as f:
            return cls.fromCsvStream(f)

    @classmethod
    def fromCsvStream(cls, lineIter: Union[TextIO, Iterable[str]]) -> 'Corpus':
        """
       Read corpus from CSV with columns
       1. id
       2. title (optional)
       3. lead (optional)
       4. text
       5. cats (pipe delimited categories)
       6. metadata (optional, JSON encoded)
       :param lineIter: input file-like object or line iterable
       :return: corpus loaded from the input
       """
        return cls(map(Doc.fromDict, csv.DictReader(lineIter)))

    @property
    def catCnt(self) -> int:
        """
        :return: size of the category set used to label the corpus
        """
        return len(self.catList)

    def filter(self, predicate: Callable[[Doc], bool]) -> 'Corpus':
        """
        Filter corpus by predicate and return a new corpus which keeps category to index mapping
        :param predicate: function returning True if a document should be kept in the filtered corpus
            and False otherwise
        :return: filtered corpus which keeps category to index mapping
        """
        newCorpus = Corpus(docs=filter(predicate, self.docs))
        newCorpus.catList = list(self.catList)
        newCorpus.catToIdx = dict(self.catToIdx)
        return newCorpus

    def filterByBools(self, bools: Sequence[bool]) -> 'Corpus':
        """
        Filter corpus by a boolean vector and return a new corpus which keeps category to index mapping
        :param bools: bool sequence of the same length as the corpus
        :return: filtered corpus which keeps category to index mapping
        """
        if len(bools) != len(self.docs):
            raise ValueError('Bool vector size does not match corpus size')
        newCorpus = Corpus(d for (d, b) in zip(self.docs, bools) if b)
        newCorpus.catList = list(self.catList)
        newCorpus.catToIdx = dict(self.catToIdx)
        return newCorpus

    def toCsv(self, file: TextIO) -> None:
        """
        Save corpus as CSV to file-like object
        :param file: writable file-like object
        """
        csvOut = csv.DictWriter(file, fieldnames=['id', 'title', 'lead', 'text', 'cats', 'metadata'])
        csvOut.writeheader()
        for doc in self.docs:
            csvOut.writerow(doc.toCsvRowDict())

    def toCsvFile(self, filePath: Union[str, Path], encoding='utf-8') -> None:
        """
        Save corpus to a CSV file
        :param filePath: name/path of the output file
        :param encoding: output file encoding
        """
        with open(filePath, 'w', encoding=encoding) as f:
            self.toCsv(f)

    def __eq__(self, other):
        return isinstance(other, Corpus) and ((self.docs, self.catCounts, self.catList, self.catToIdx)
                                              == (other.docs, other.catCounts, other.catList, other.catToIdx))

    def __len__(self) -> int:
        return len(self.docs)

    def __iter__(self):
        return iter(self.docs)

    def __getitem__(self, i: int) -> Doc:
        return self.docs[i]

    def __repr__(self) -> str:
        return f'{self.__class__.__qualname__}(docs={len(self.docs)}, cats={self.catCnt})'


def stackCorpora(*corpora: Corpus, keepIndex: bool = False) -> Corpus:
    """
    Create concatenated corpus
    :param corpora: input corpora
    :param keepIndex: if set to True, the function checks that all corpora have the same category to index mapping
        which will also be used for the concatenated corpus. If set to False, the stacked corpus will contain
        a union of categories of input corpora with newly assigned indices.
    :return: concatenated corpus with the order of documents determined by the order of input corpora
    """
    stackedCorpus = Corpus(itertools.chain(*corpora))

    if keepIndex:
        for i in range(len(corpora) -1):
            if corpora[i].catToIdx != corpora[i + 1].catToIdx:
                raise ValueError('Corpora with different cat-to-index mapping not allowed with keepIndex=True')
        stackedCorpus.catToIdx = corpora[0].catToIdx
        stackedCorpus.catList = corpora[0].catList

    return stackedCorpus


class CorpusGroup:
    """
    Group of train, dev and test corpora. At creation, it synchronizes category lists/indices
    across the three corpora.
    """

    def __init__(self, train: Corpus, dev: Corpus = None, test: Corpus = None):
        """
        Create corpus group of train, dev and test corpora and synchronize category lists/indices
        across the three corpora.
        :param train: train corpus
        :param dev: dev corpus
        :param test: test corpus
        """
        self.train = train
        self.dev = dev
        self.test = test
        self.catList, self.catToIdx = self._syncCats()

    @classmethod
    def fromCsv(cls, *,
            trainPath: Union[str, Path],
            devPath: Union[str, Path] = None,
            testPath: Union[str, Path] = None
    ) -> 'CorpusGroup':
        """
        Read corpora from CSV files with columns
        1. id
        2. title (optional)
        3. lead (optional)
        4. text
        5. cats (pipe delimited categories)
        6. metadata (optional, JSON encoded)
        :param trainPath: train CSV file path
        :param devPath: dev CSV file path
        :param testPath: test CSV file path
        :return: corpus loaded from the file
        """
        return CorpusGroup(
            train=Corpus.fromCsv(trainPath),
            dev=Corpus.fromCsv(devPath) if devPath else None,
            test=Corpus.fromCsv(testPath) if testPath else None
        )

    def asTuple(self) -> Tuple[Corpus, Corpus, Corpus]:
        """
        :return: corpora tuple (train, dev, test)
        """
        return self.train, self.dev, self.test

    def _syncCats(self) -> Tuple[List[str], Dict[str, int]]:
        """
        Synchronize categories list and indices across train, test and dev corpora.
        Log differences in category sets.
        """
        LOG.info(f'Category count in train: {self.train.catCnt}')
        if self.dev:
            LOG.info(f'Category count in dev: {self.dev.catCnt}')
        if self.test:
            LOG.info(f'Category count in test: {self.test.catCnt}')

        if self.dev:
            trainDevDiff = sorted(set(self.train.catList) - set(self.dev.catList))
            devTrainDiff = sorted(set(self.dev.catList) - set(self.train.catList))
        else:
            trainDevDiff = []
            devTrainDiff = []

        if self.test:
            trainTestDiff = sorted(set(self.train.catList) - set(self.test.catList))
            testTrainDiff = sorted(set(self.test.catList) - set(self.train.catList))
        else:
            trainTestDiff = []
            testTrainDiff = []

        if trainDevDiff:
            LOG.warning(f'Categories in train not in dev {trainDevDiff}')
        if trainTestDiff:
            LOG.warning(f'Categories in train not in test {trainTestDiff}')
        if devTrainDiff:
            LOG.warning(f'Categories in dev not in train {devTrainDiff}')
        if testTrainDiff:
            LOG.warning(f'Categories in test not in train {testTrainDiff}')

        globalCatList = sorted(
            set(self.train.catList)
            | (set(self.dev.catList) if self.dev else set())
            | (set(self.test.catList) if self.test else set())
        )
        globalCatToIdx = {c: i for i, c in enumerate(globalCatList)}

        self.train.catList = globalCatList
        self.train.catToIdx = globalCatToIdx

        if self.dev:
            self.dev.catList = globalCatList
            self.dev.catToIdx = globalCatToIdx

        if self.test:
            self.test.catList = globalCatList
            self.test.catToIdx = globalCatToIdx

        return globalCatList, globalCatToIdx

    @property
    def catCnt(self) -> int:
        """
        :return: size of the category set used to label the corpora
        """
        return len(self.catList)

    def __repr__(self) -> str:
        return f'{self.__class__.__qualname__}(train={self.train!r}, dev={self.dev!r}, test={self.test!r})'
