"""
Tools for conversion of objects (mainly text related) into vectors.
"""

import geneea.embedclient.client as embedclient
import numpy as np

from abc import abstractmethod

from typing import Any, Dict, Generic, Sequence, Tuple, Type, TypeVar, Union

from geneea.core import logutil

from geneea.catlib.data import Doc


T = TypeVar('T')

DEV_EMBED_SVC_URL = 'http://tau.g:5533'

LOG = logutil.getLogger(__package__, __file__)


class Vectorizer(Generic[T]):
    """
    Interface for vectorization - conversion to vectors of fixed length
    """

    @property
    @abstractmethod
    def dim(self) -> int:
        """
        :return: dimension of returned vectors
        """
        pass

    @abstractmethod
    def toVec(self, item: T) -> np.ndarray:
        """
        :param item: input item
        :return: vector representation of the item
        """
        pass

    @abstractmethod
    def toMatrix(self, items: Sequence[T]) -> np.ndarray:
        """
        :param items: input items
        :return: matrix representation of the items (number of items x vector dimension)
        """
        pass

    def _debugVecBase(self):
        return {'vectorizer': self.__class__.__qualname__, 'dim': self.dim}

    def _debugMatrixBase(self, items):
        return {'vectorizer': self.__class__.__qualname__, 'dim': self.dim, 'rows': len(items)}

    def debugToVec(self, item: T) -> Tuple[np.ndarray, Dict]:
        """
        Vectorize given item and provide debug information
        :param  item: input item
        :return: tuple (vector, debug info as a dict)
        """
        return self.toVec(item), self._debugVecBase()

    def debugToMatrix(self, items: Sequence[T]) -> Tuple[np.ndarray, Dict]:
        """
        Vectorize given items and provide debug information
        :param  items: input items
        :return: tuple (matrix, debug info as a dict)
        """
        return self.toMatrix(items), self._debugMatrixBase(items)

    def debugInfo(self) -> Any:
        """
        :return: debug information about the vectorizer
        """
        return repr(self)


class DocVectorizer(Vectorizer[Doc]):

    @classmethod
    def fromTextVectorizer(cls, textVectorizer: Vectorizer[str]) -> 'TextDocVectorizer':
        """
        :param textVectorizer: text vectorizer
        :return: document vectorizer which flattens the document into single string and uses a text vectorizer
        """
        return TextDocVectorizer(textVectorizer=textVectorizer)


class TextDocVectorizer(DocVectorizer):
    """
    Document vectorizer which flattens the document into single string and embeds it using a text vectorizer
    """

    def __init__(self, textVectorizer: Vectorizer[str]):
        self.textVectorizer = textVectorizer

    def toVec(self, item: Doc) -> np.ndarray:
        return self.textVectorizer.toVec(item.allText)

    def toMatrix(self, items: Sequence[Doc]) -> np.ndarray:
        return self.textVectorizer.toMatrix([doc.allText for doc in items])

    @property
    def dim(self) -> int:
        return self.textVectorizer.dim

    def __repr__(self) -> str:
        return f'{self.__class__.__qualname__}(textVectorizer={self.textVectorizer!r})'


class SvcTextVectorizer(Vectorizer[str]):
    """
    Text vectorizer which retrieves embeddings by calling a REST service
    """

    def __init__(self, embedSvcUrl: str, modelId: str = None, embedDim: int = 1024, dtype: Union[Type[np.number], str] = None) -> None:
        """
        :param embedSvcUrl: URL of embedding service
        :param embedDim: embedding dimension (default 1024)
        :param dtype: vector data type (NumPy dtype, default float32)
        """
        self.embedSvcUrl = embedSvcUrl
        self.embedDim = embedDim
        self.dtype = dtype or np.float32
        self.client = embedclient.Client.create(url=self.embedSvcUrl, docModelId=modelId)

    def toVec(self, item: str) -> np.ndarray:
        return self.toMatrix([item])[0]

    def toMatrix(self, items: Sequence[str]) -> np.ndarray:
        embMatrix = np.zeros((len(items), self.embedDim), dtype=self.dtype)
        i = 0

        for batchMatrix in self.client.embedDocsIter(texts=items):
            batchSize = batchMatrix.shape[0]
            embMatrix[i:i + batchSize] = batchMatrix
            i += batchSize

        assert i == len(items)

        return embMatrix

    @property
    def dim(self) -> int:
        return self.embedDim

    def __repr__(self) -> str:
        return (f'{self.__class__.__qualname__}'
                f'(embedSvcUrl={self.embedSvcUrl}, modelId={self.client.docModelId},'
                f' embedDim={self.embedDim}, dtype={self.dtype!r})')


def defaultEmbedTextVectorizer(embedSvcUrl=DEV_EMBED_SVC_URL) -> Vectorizer[str]:
    """
    :return: default embedding-based text vectorizer using a REST API
    """
    return SvcTextVectorizer(embedSvcUrl=embedSvcUrl, embedDim=1024)
