from geneea.catlib.vec.util import catsToVec, vecToCats, vecToScoredCats
from geneea.catlib.vec.vectorizer import Vectorizer
