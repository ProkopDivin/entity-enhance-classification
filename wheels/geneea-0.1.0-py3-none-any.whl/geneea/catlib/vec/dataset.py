"""
Dataset combining a textual categorization corpus and document embeddings.
"""

import numpy as np
import torch

from collections import Counter
from pathlib import Path
from typing import Callable, Dict, List, Sequence, Tuple, Union

from geneea.core import logutil
from torch.utils.data import Dataset

from geneea.catlib.data import Corpus, Doc, stackCorpora
from geneea.catlib.vec import catsToVec
from geneea.catlib.vec.vectorizer import defaultEmbedTextVectorizer, Vectorizer, TextDocVectorizer


LOG = logutil.getLogger(__package__, __file__)


class EmbeddingDataset(Dataset):
    """
    Dataset combining a textual categorization corpus and document embeddings. Supports customizable
    embedding computation via Vectorizer and saving/loading embeddings to avoid re-computation.

    The class implements PyTorch Dataset interface and represents the embeddings (X) and the category vectors (Y)
    as PyTorch tensors.
    """

    def __init__(self, corpus: Corpus, X: torch.Tensor, Y: torch.Tensor):
        """
        Low-level constructor
        :param corpus: textual categorization corpus
        :param X: embedding matrix (doc count x embedding dim)
        :param Y: category matrix (doc count x cat count)
        """
        self.corpus = corpus
        self.X = X
        self.Y = Y

    @property
    def catList(self) -> List[str]:
        return self.corpus.catList

    @property
    def catToIdx(self) -> Dict[str, int]:
        return self.corpus.catToIdx

    @property
    def catCnt(self) -> int:
        return self.corpus.catCnt

    @property
    def catCounts(self) -> Counter:
        return self.corpus.catCounts
    
    def load_temporary(self) -> None:
        pass

    def cleanup_temporary(self) -> None:
        pass
      
    @classmethod
    def fromCorpus(cls,
            corpus: Corpus,
            embedFile: Union[str, Path] = None,
            partialEmbedFile: Union[str, Path] = None,
            vectorizer: Vectorizer[Doc] = None,
            useScores: bool = False,
            defaultScore: float = 0.75,
            scoreMetaField: str = 'catScores',
            smoothing: float = 0.0,
            embedDim: int = 1024
    ) -> 'EmbeddingDataset':
        """
        Create a dataset for corpus. Embeddings are either computed or loaded from a file.
        :param corpus: textual categorization corpus
        :param embedFile: file to read embeddings from. If not specified, embeddings will be computed using vectorizer
        :param partialEmbedFile: read embeddings for part of the corpus from file
            and compute the missing ones using vectorizer
        :param vectorizer: document embedding computation. If not specified, the default, service-based, will be used
        :param useScores: use category scores from metadata
        :param defaultScore: if `useScores` is set to True, this score will be used in cases when
            a document doesn't provide a score for given category
        :param scoreMetaField: if `useScores` is set to True, extract scores from this metadata field
        :param smoothing: value to use in category vectors for categories which do not belong to given texts (default 0)
        :param embedDim: embedding dimension (default 1024)
        :return: dataset for given corpus
        """
        hasAnnot = corpus.catCnt != 0

        if embedFile:
            X = cls.loadX(embedFile=embedFile, corpus=corpus, embedDim=embedDim)
        else:
            if not vectorizer:
                vectorizer = cls.defaultVectorizer()
            if partialEmbedFile:
                X = cls.loadXPartial(embedFile=partialEmbedFile, corpus=corpus, vectorizer=vectorizer)
            else:
                X = cls.computeX(corpus=corpus, vectorizer=vectorizer)

        if hasAnnot:
            Y = torch.zeros((len(corpus), corpus.catCnt))
            for i, doc in enumerate(corpus):
                if useScores:
                    Y[i] = torch.from_numpy(catsToVec(
                        doc.cats,
                        catToIdx=corpus.catToIdx,
                        catScores=doc.metadata.get(scoreMetaField),
                        trueVal=defaultScore,
                        falseVal=smoothing
                    ))
                else:
                    Y[i] = torch.from_numpy(catsToVec(doc.cats, corpus.catToIdx, falseVal=smoothing))

        else:
            Y = torch.zeros((len(corpus), 1))

        return cls(corpus, X, Y)

    def saveEmbeds(self, fileName: Union[str, Path]) -> None:
        """
        Save embeddings as TSV (docId, space delimited vector elements)
        :param fileName: output file name
        """
        with open(fileName, 'w', encoding='utf-8') as f:
            for i, doc in enumerate(self.corpus):
                print(doc.id, ' '.join(f'{v:.4g}' for v in self.X[i]), sep='\t', file=f)

    @classmethod
    def loadX(cls, embedFile: Union[str, Path], corpus: Corpus, embedDim: int = 1024) -> torch.Tensor:
        X = torch.zeros(len(corpus), embedDim)

        embedCnt = 0
        with open(embedFile, encoding='utf-8') as f:
            for i, line in enumerate(f):
                embedCnt += 1
                docId, vecStr = line.strip().split('\t')
                if docId != corpus[i].id:
                    raise ValueError(f'Unexpected docID on line {i + 1}: {docId}; should be {corpus[i].id}')

                vec = torch.tensor([float(v) for v in vecStr.split()])
                if vec.shape != (embedDim,):
                    raise ValueError(
                        f'Unexpected vector dimension on line {i + 1}: {vec.shape[0]}; should be {embedDim}')
                X[i] = vec

        if embedCnt != len(corpus):
            raise ValueError(f'Loaded {embedCnt} vectors but {len(corpus)} needed')

        return X

    @classmethod
    def loadXPartial(cls, embedFile: Union[str, Path], corpus: Corpus, vectorizer: Vectorizer[Doc]) -> torch.Tensor:
        docIdToIdx = {d.id: i for (i, d) in enumerate(corpus)}
        if len(docIdToIdx) != len(corpus):
            raise ValueError('Document IDs are not unique. Partial loading not supported.')

        embedDim = vectorizer.dim
        X = torch.zeros(len(corpus), embedDim)

        loadedDocId = set()
        with open(embedFile, encoding='utf-8') as f:
            for i, line in enumerate(f):
                docId, vecStr = line.strip().split('\t')

                if docId in docIdToIdx:
                    vec = torch.tensor([float(v) for v in vecStr.split()])
                    if vec.shape != (embedDim,):
                        raise ValueError(
                            f'Unexpected vector dimension on line {i + 1}: {vec.shape[0]}; should be {embedDim}')

                    X[docIdToIdx[docId]] = vec
                    loadedDocId.add(docId)
        LOG.info(f'Loaded {len(loadedDocId)} embeddings out of {len(corpus)}')

        missingEmbDocs = [d for d in corpus if d.id not in loadedDocId]
        computedEmbs = torch.from_numpy(vectorizer.toMatrix(missingEmbDocs))
        for i, doc in enumerate(missingEmbDocs):
            X[docIdToIdx[doc.id]] = computedEmbs[i]

        return X

    @classmethod
    def computeX(cls, corpus: Corpus, vectorizer: Vectorizer[Doc]) -> torch.Tensor:
        return torch.from_numpy(vectorizer.toMatrix(corpus.docs))

    @classmethod
    def defaultVectorizer(cls) -> Vectorizer[Doc]:
        return TextDocVectorizer(textVectorizer=defaultEmbedTextVectorizer())

    @property
    def embedDim(self) -> int:
        return self.X.shape[1]

    def filter(self, predicate: Callable[[Doc], bool]) -> 'EmbeddingDataset':
        """
        Filter dataset by predicate and return a new corpus which keeps category to index mapping
        :param predicate: function returning True if a document should be kept in the filtered dataset
            and False otherwise
        :return: filtered dataset which keeps category to index mapping
        """
        return self.filterByBools([predicate(d) for d in self.corpus])

    def filterByBools(self, bools: Sequence[bool]) -> 'EmbeddingDataset':
        """
        Filter dataset by a boolean vector and return a new dataset which keeps category to index mapping
        :param bools: bool sequence of the same length as the dataset
        :return: filtered dataset which keeps category to index mapping
        """
        return EmbeddingDataset(corpus=self.corpus.filterByBools(bools), X=self.X[bools], Y=self.Y[bools])

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[idx], self.Y[idx]

    def getDocEmbed(self, idx: int) -> np.ndarray:
        """
        :param idx: document index
        :return: embedding vector for the document, as numpy ndarray
        """
        return self.X[idx].cpu().numpy()

    def getDocCatVec(self, idx: int) -> np.ndarray:
        """
        :param idx: document index
        :return: category vector for the document, as numpy ndarray
        """
        return self.Y[idx].cpu().numpy()

    def __repr__(self) -> str:
        return f'{self.__class__.__qualname__}(docs={len(self.corpus)}, cats={self.catCnt}, dim={self.embedDim})'


def stackDatasets(*datasets: EmbeddingDataset) -> EmbeddingDataset:
    """
    Concatenate datasets. Only datasets with identical embedding dimension and category-to-index mapping
        are supported.
    :param datasets: input datasets
    :return: concatenated dataset with the order of documents determined by the order of input corpora
    """
    return EmbeddingDataset(
        corpus=stackCorpora(*[ds.corpus for ds in datasets], keepIndex=True),
        X=torch.vstack(tuple(ds.X for ds in datasets)),
        Y=torch.vstack(tuple(ds.Y for ds in datasets)),
    )
