"""
Helper methods for working with embeddings and related data used for categorization.
"""

import numpy as np

from typing import List, Mapping, Sequence, Tuple, Type, TypeVar, Union


T = TypeVar('T')


def catsToVec(
        cats: Sequence[T],
        catToIdx: Mapping[T, int],
        *,
        catScores: Mapping[T, float] = None,
        trueVal: float = 1.0,
        falseVal: float = 0.0,
        dtype: Union[Type[np.number], str] = None
) -> np.ndarray:
    """
    Convert category list to a "one-hot" vector
    :param cats: list of (selected) categories
    :param catToIdx: mapping from all categories to index
    :param catScores: mapping from categories to score to use instead of `trueVal`
    :param trueVal: value to use in the vector for listed categories
    :param falseVal: value to use in the vector for categories not in the `cats` list
    :param dtype: vector data type (NumPy dtype, default float32)
    :return: vector of length == len(catToIdx) with `trueVal` on indices of categories in `cats` list and
        falseVal for other categories
    """
    vec = np.full(len(catToIdx), falseVal, dtype=dtype or np.float32)

    if not catScores:
        for c in cats:
            vec[catToIdx[c]] = trueVal
    else:
        for c in cats:
            vec[catToIdx[c]] = catScores.get(c, trueVal)

    return vec


def vecToCats(vec: np.ndarray, catList: Sequence[T], thr: float = 0.5) -> List[T]:
    """
    Convert a vector to a list of selected categories
    :param vec: input vector
    :param catList: list of all categories (same length as the vector; position in the list corresponds to position
        int the vector)
    :param thr: threshold above which a category is selected (select catList[i] if vec[i] > thr)
    :return: list of selected categories
    """
    if vec.shape != (len(catList),):
        raise ValueError(f'Vector shape does not match category count ({vec.shape} vs ({len(catList)},) expected)')
    return [catList[i] for i in range(len(catList)) if vec[i] > thr]


def vecToScoredCats(vec: np.ndarray, catList: Sequence[T], thr: float = 0.5) -> List[Tuple[T, float]]:
    """
    Convert a vector to a list of tuples (selected category, vector value for given category)
    :param vec: input vector
    :param catList: list of all categories (same length as the vector; position in the list corresponds to position
        int the vector)
    :param thr: threshold above which a category is selected (select catList[i] if vec[i] > thr)
    :return: list of tuples (selected category, vector value for given category)
    """
    if vec.shape != (len(catList),):
        raise ValueError(f'Vector shape does not match category count ({vec.shape} vs ({len(catList)},) expected)')
    return [(catList[i], float(vec[i])) for i in range(len(catList)) if vec[i] > thr]
