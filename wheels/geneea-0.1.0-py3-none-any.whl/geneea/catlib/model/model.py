"""
Categorization model ABC and label filtering helpers used by the neural classifier.
"""

from abc import ABC, abstractmethod
from operator import itemgetter
from typing import Any, Generic, List, Mapping, Protocol, Sequence, Tuple, TypeVar, Union

LabelT = TypeVar('LabelT')
WghLabels = Sequence[Tuple[LabelT, float]]

UNK_LABEL = 'Unknown'


class Analysis(Protocol):
    '''Minimal Analysis protocol used by TextFromAnalysisModel.'''

    paragraphs: Sequence[Any]


class Model(ABC, Generic[LabelT]):
    """
    Categorization model abstract class
    """

    def supportsText(self) -> bool:
        """
        @return: true IFF the model can work with text inputs
        """
        return True

    @abstractmethod
    def predictText(self, text: str) -> WghLabels:
        """
        Predict weighted labels for given text.
        @param text: input text
        @return: classification result as a list of (label, confidence score) pairs
        """
        pass

    def predictTextBatch(self, texts: Sequence[str]) -> List[WghLabels]:
        """
        Predict weighted labels for given texts.
        @param texts: input texts
        @return: corresponding batch of classification results as a list of (label, confidence score) pairs
        """
        return [self.predictText(text) for text in texts]

    def supportsAnalysis(self) -> bool:
        """
        @return: true IFF the model can work with Analysis object inputs
        """
        return True

    @abstractmethod
    def predictAnalysis(self, analysis: Analysis) -> WghLabels:
        """
        Predict weighted labels for given Analysis object.
        @param analysis: input Analysis object
        @return: classification result as a list of (label, confidence score) pairs
        """
        pass

    def predictAnalysisBatch(self, analyses: Sequence[Analysis]) -> List[WghLabels]:
        """
        Predict weighted labels for given Analysis objects.
        @param analyses: input Analysis objects
        @return: corresponding batch of classification results as a list of (label, confidence score) pairs
        """
        return [self.predictAnalysis(a) for a in analyses]


class TextFromAnalysisModel(Model[LabelT]):
    """
    Model that only uses text for classification but also accepts Analysis objects from which it extracts document texts.
    """

    def _analysisToText(self, analysis: Analysis) -> str:
        """
        Simply joins texts from all paragraphs by two new-lines. Can be overridden if required.
        """
        return '\n\n'.join(p.text for p in analysis.paragraphs if p.text)

    def predictAnalysis(self, analysis: Analysis) -> WghLabels:
        return self.predictText(self._analysisToText(analysis))

    def predictAnalysisBatch(self, analyses: Sequence[Analysis]) -> List[WghLabels]:
        return self.predictTextBatch([self._analysisToText(a) for a in analyses])


def filterLabels(
        labels: WghLabels,
        thr: float = 0.0,
        topn: int = None,
        keepWgh: bool = True,
        thrByLabel: Mapping[LabelT, float] = None
) -> Union[WghLabels, List[LabelT]]:
    """
    Filter weighted labels
    :param labels: input labels
    :param thr: minimum score (return only labels with score >= thr)
    :param topn: return top N highest scoring labels
    :param keepWgh: if set to False, return only a list of labels without scores
    :param thrByLabel: mapping label -> custom threshold for that label
    :return: filtered labels
    """
    thrByLabel = thrByLabel or {}
    outLabels = [(l, s) for (l, s) in labels if s >= thrByLabel.get(l, thr)]
    if topn:
        outLabels = sorted(outLabels, key=itemgetter(1), reverse=True)[:topn]

    if not keepWgh:
        outLabels = [l for (l, _) in outLabels]

    return outLabels
