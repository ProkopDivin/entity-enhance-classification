"""
Neural network classifier
"""
import numpy as np
import torch
import torch.nn as nn

from operator import itemgetter
from typing import Any, Callable, Iterable, List, Mapping, Sequence, Tuple, Type, TypeVar, Union

from geneea.core import logutil
from gensim.utils import SaveLoad
from torch.utils.data import DataLoader

from geneea.catlib.data import Doc, Corpus
from geneea.catlib.vec import vecToScoredCats, vecToCats
from geneea.catlib.vec.dataset import EmbeddingDataset
from geneea.catlib.vec.vectorizer import defaultEmbedTextVectorizer, DocVectorizer, Vectorizer
from geneea.catlib.model.model import LabelT, TextFromAnalysisModel, WghLabels


LOG = logutil.getLogger(__package__, __file__)

ParamsT = TypeVar('ParamsT')


def detectTorchDevice() -> torch.device:
    """
    :return: GPU device (cuda) if available, otherwise CPU
    """
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def _batch_to_device(batch: Any, *, device: torch.device) -> Any:
    """Move tensor containers to target device."""
    if torch.is_tensor(batch):
        return batch.to(device)
    if isinstance(batch, dict):
        return {key: _batch_to_device(value, device=device) for key, value in batch.items()}
    if isinstance(batch, tuple):
        return tuple(_batch_to_device(item, device=device) for item in batch)
    if isinstance(batch, list):
        return [_batch_to_device(item, device=device) for item in batch]
    return batch

class MLPNN(nn.Module):
    """
    Interface for MLP-based NN architectures
    """

    def __init__(self):
        super(MLPNN, self).__init__()

    @classmethod
    def create(cls,
            embDim: int,
            outDim: int,
            hiddenDim: int,
            *,
            dropouts: Tuple[float, float] = (0.0, 0.0),
            **kwargs: Any,
    ) -> 'MLPNN':
        return cls(embDim=embDim, outDim=outDim, hiddenDim=hiddenDim, dropouts=dropouts, **kwargs)


class MLP(MLPNN):
    """
    Multi-layer perceptron neural network
    """
    def __init__(self, embDim: int, outDim: int, hiddenDim: int, *, dropouts: Tuple[float, float] = (0.0, 0.0)) -> None:
        super(MLP, self).__init__()
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(embDim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim)
        )

    def forward(self, x) -> torch.Tensor:
        logits = self.linear_relu_stack(x)
        return logits


class MLPGELU(MLPNN):
    """Multi-layer perceptron neural network using GELU activation."""

    def __init__(self, embDim: int, outDim: int, hiddenDim: int, *, dropouts: Tuple[float, float] = (0.0, 0.0)) -> None:
        super(MLPGELU, self).__init__()
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(embDim, hiddenDim),
            nn.GELU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )

    def forward(self, x) -> torch.Tensor:
        logits = self.linear_relu_stack(x)
        return logits


class SkipMLP(MLPNN):
    """
    Multi-layer perceptron with skip connection and concatenation
    """
    def __init__(self, embDim: int, outDim: int, hiddenDim: int, *, dropouts: Tuple[float, float] = (0.0, 0.0)) -> None:
        super(SkipMLP, self).__init__()
        self.dropout0 = nn.Dropout(dropouts[0])
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(embDim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1])
        )
        self.finalLinear = nn.Linear(hiddenDim + embDim, outDim)

    def forward(self, x) -> torch.Tensor:
        linres = self.linear_relu_stack(x)
        logits = self.finalLinear(torch.cat((self.dropout0(x), linres), 1))
        return logits


class LeakyMLP(MLPNN):
    """
    Multi-layer perceptron with leaky ReLU activation
    """
    def __init__(self, embDim: int, outDim: int, hiddenDim: int, *, dropouts: Tuple[float, float] = (0.0, 0.0),negative_slope: float = 0.01) -> None:
        super(LeakyMLP, self).__init__()
        self.linear_leaky_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(embDim, hiddenDim),
            nn.LeakyReLU(negative_slope=negative_slope),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )
        
    def forward(self, x) -> torch.Tensor:
        logits = self.linear_leaky_relu_stack(x)
        return logits

class EntityNoPoolingMLP(MLPNN):
    """
    Scaffold model for no-pooling entity inputs.
    """
    def __init__(self, embDim: int, outDim: int, hiddenDim: int, *, dropouts: Tuple[float, float] = (0.0, 0.0)) -> None:
        super(EntityNoPoolingMLP, self).__init__()
        self.emb_dim = embDim
        self.out_dim = outDim
        self.hidden_dim = hiddenDim
        self.dropouts = dropouts

    def forward(self, x):
        pass


class EntityAttention3MLP(MLPNN):
    """MLP with per-entity attention and a document-level gate on the pooled entity vector."""

    def __init__(
        self,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        entityDim: int,
        dropouts: Tuple[float, float] = (0.0, 0.0),
    ) -> None:
        super().__init__()
        self.fusion_gate = nn.Linear(embDim + entityDim, 2)
        combined_dim = embDim + entityDim
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(combined_dim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )
    @classmethod
    def create(
        cls,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        dropouts: Tuple[float, float] = (0.0, 0.0),
        entityDim: int,

        **kwargs: Any,
    ) -> 'EntityAttention3MLP':
        del kwargs
        return cls(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            dropouts=dropouts,
        )

    def forward(self, x: Mapping[str, torch.Tensor]) -> torch.Tensor:
        article = x['article_embeddings']
        entities = x['entity_embeddings']
        entity_mask = x['entity_mask'].to(dtype=entities.dtype).unsqueeze(-1)
        article_expanded = article.unsqueeze(1).expand(-1, entities.shape[1], -1)
        attn_input = torch.cat((article_expanded, entities), dim=-1)
        token_gate = torch.softmax(self.fusion_gate(attn_input), dim=-1)
        entity_token_weight = token_gate[..., 1:2] * entity_mask
        weight_sum = entity_token_weight.sum(dim=1).clamp_min(1e-8)
        pooled_entities = (entities * entity_token_weight).sum(dim=1) / weight_sum
        input_no_weights = torch.cat((article, pooled_entities), dim=1)
        final_gate = torch.softmax(self.fusion_gate(input_no_weights), dim=1)
        weighted_article = article * final_gate[:, 0:1]
        weighted_entities = pooled_entities * final_gate[:, 1:2]
        combined = torch.cat((weighted_article, weighted_entities), dim=1)
        return self.linear_relu_stack(combined)



class EntityAttention2MLP(MLPNN):
    """MLP with per-entity attention and a document-level gate on the pooled entity vector."""

    def __init__(
        self,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        entityDim: int,
        attentionHiddenDim: int,
        attentionDropout: float = 0.0,
        dropouts: Tuple[float, float] = (0.0, 0.0),
    ) -> None:
        super().__init__()
        self.attn_stack = nn.Sequential(
            nn.Linear(embDim + entityDim, attentionHiddenDim),
            nn.ReLU(),
            nn.Dropout(attentionDropout),
            nn.Linear(attentionHiddenDim, 1),
            nn.Sigmoid(),
        )
        combined_dim = embDim + entityDim
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(combined_dim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )

    @classmethod
    def create(
        cls,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        dropouts: Tuple[float, float] = (0.0, 0.0),
        entityDim: int,
        attentionHiddenDim: int,
        attentionDropout: float = 0.0,
        **kwargs: Any,
    ) -> 'EntityAttention2MLP':
        del kwargs
        return cls(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            attentionHiddenDim=attentionHiddenDim,
            attentionDropout=attentionDropout,
            dropouts=dropouts,
        )

    def forward(self, x: Mapping[str, torch.Tensor]) -> torch.Tensor:
        article = x['article_embeddings']
        entities = x['entity_embeddings']
        entity_mask = x['entity_mask'].to(dtype=entities.dtype).unsqueeze(-1)

        article_expanded = article.unsqueeze(1).expand(-1, entities.shape[1], -1)
        attn_input = torch.cat((article_expanded, entities), dim=-1)
        attn_weights = self.attn_stack(attn_input) * entity_mask
        weighted_entities = entities * attn_weights
        weight_sum = attn_weights.sum(dim=1).clamp_min(1e-8)
        pooled_entities = weighted_entities.sum(dim=1) / weight_sum
        
        # weighting also entity vector itself 
        combined = torch.cat((article, pooled_entities), dim=1)
        entity_vector_w = self.attn_stack(combined)
        pooled_entities = pooled_entities * entity_vector_w
        final_input = torch.cat((article, pooled_entities), dim=1)
        return self.linear_relu_stack(final_input)


class EntityAttentionMLP(MLPNN):
    """MLP with per-entity attention over ragged entity embeddings."""

    def __init__(
        self,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        entityDim: int,
        attentionHiddenDim: int,
        attentionDropout: float = 0.0,
        dropouts: Tuple[float, float] = (0.0, 0.0),
    ) -> None:
        super().__init__()
        self.attn_stack = nn.Sequential(
            nn.Linear(embDim + entityDim, attentionHiddenDim),
            nn.ReLU(),
            nn.Dropout(attentionDropout),
            nn.Linear(attentionHiddenDim, 1),
            nn.Sigmoid(),
        )
        combined_dim = embDim + entityDim
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(combined_dim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )

    @classmethod
    def create(
        cls,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        dropouts: Tuple[float, float] = (0.0, 0.0),
        entityDim: int,
        attentionHiddenDim: int,
        attentionDropout: float = 0.0,
        **kwargs: Any,
    ) -> 'EntityAttentionMLP':
        del kwargs
        return cls(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            attentionHiddenDim=attentionHiddenDim,
            attentionDropout=attentionDropout,
            dropouts=dropouts,
        )

    def forward(self, x: Mapping[str, torch.Tensor]) -> torch.Tensor:
        article = x['article_embeddings']
        entities = x['entity_embeddings']
        entity_mask = x['entity_mask'].to(dtype=entities.dtype).unsqueeze(-1)

        article_expanded = article.unsqueeze(1).expand(-1, entities.shape[1], -1)
        attn_input = torch.cat((article_expanded, entities), dim=-1)
        attn_weights = self.attn_stack(attn_input) * entity_mask
        weighted_entities = entities * attn_weights
        weight_sum = attn_weights.sum(dim=1).clamp_min(1e-8)
        pooled_entities = weighted_entities.sum(dim=1) / weight_sum

        combined = torch.cat((article, pooled_entities), dim=1)
        return self.linear_relu_stack(combined)


class EntityMhaAttentionMLP(MLPNN):
    """MLP with article-query multi-head attention over ragged entity embeddings."""

    def __init__(
        self,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        entityDim: int,
        attentionNumHeads: int = 1,
        attentionDropout: float = 0.0,
        dropouts: Tuple[float, float] = (0.0, 0.0),
    ) -> None:
        super().__init__()
        if attentionNumHeads <= 0:
            raise ValueError(f'attentionNumHeads must be positive, got {attentionNumHeads}.')
        if entityDim % attentionNumHeads != 0:
            raise ValueError(
                f'entityDim must be divisible by attentionNumHeads: entityDim={entityDim}, heads={attentionNumHeads}.',
            )
        self.article_projection = nn.Linear(embDim, entityDim)
        self.entity_attention = nn.MultiheadAttention(
            embed_dim=entityDim,
            num_heads=attentionNumHeads,
            dropout=attentionDropout,
            batch_first=True,
        )
        combined_dim = embDim + entityDim
        self.linear_relu_stack = nn.Sequential(
            nn.Dropout(dropouts[0]),
            nn.Linear(combined_dim, hiddenDim),
            nn.ReLU(),
            nn.Dropout(dropouts[1]),
            nn.Linear(hiddenDim, outDim),
        )

    @classmethod
    def create(
        cls,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        dropouts: Tuple[float, float] = (0.0, 0.0),
        entityDim: int,
        attentionNumHeads: int = 1,
        attentionDropout: float = 0.0,
        **kwargs: Any,
    ) -> 'EntityMhaAttentionMLP':
        del kwargs
        return cls(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            attentionNumHeads=attentionNumHeads,
            attentionDropout=attentionDropout,
            dropouts=dropouts,
        )

    def _compute_attention_pool(
        self,
        *,
        article: torch.Tensor,
        entities: torch.Tensor,
        entity_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        valid_mask = entity_mask.to(dtype=torch.bool)
        key_padding_mask = torch.logical_not(valid_mask)
        has_entities = valid_mask.any(dim=1)
        safe_entities = entities
        safe_padding_mask = key_padding_mask
        if torch.any(~has_entities):
            safe_padding_mask = key_padding_mask.clone()
            safe_padding_mask[~has_entities, 0] = False
            safe_entities = entities.clone()
            safe_entities[~has_entities, 0, :] = 0.0
        query = self.article_projection(article).unsqueeze(1)
        attn_output, attn_weights = self.entity_attention(
            query=query,
            key=safe_entities,
            value=safe_entities,
            key_padding_mask=safe_padding_mask,
            need_weights=True,
            average_attn_weights=False,
        )
        pooled_entities = attn_output.squeeze(1)
        pooled_entities = pooled_entities * has_entities.to(dtype=pooled_entities.dtype).unsqueeze(-1)
        attn_weights = attn_weights.squeeze(2)
        attn_weights = attn_weights * valid_mask.unsqueeze(1).to(dtype=attn_weights.dtype)
        return pooled_entities, attn_weights

    def forward(self, x: Mapping[str, torch.Tensor]) -> torch.Tensor:
        article = x['article_embeddings']
        entities = x['entity_embeddings']
        entity_mask = x['entity_mask']
        pooled_entities, _ = self._compute_attention_pool(
            article=article,
            entities=entities,
            entity_mask=entity_mask,
        )
        combined = torch.cat((article, pooled_entities), dim=1)
        return self.linear_relu_stack(combined)


class EntityMhaAttention2MLP(EntityMhaAttentionMLP):
    """MHA entity model with pooled-entity scaling derived from attention weights."""

    def __init__(
        self,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        entityDim: int,
        attentionNumHeads: int = 1,
        attentionDropout: float = 0.0,
        dropouts: Tuple[float, float] = (0.0, 0.0),
    ) -> None:
        super().__init__(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            attentionNumHeads=attentionNumHeads,
            attentionDropout=attentionDropout,
            dropouts=dropouts,
        )
        self.article_norm = nn.LayerNorm(embDim)
        self.entity_norm = nn.LayerNorm(entityDim)
        self.fusion_gate = nn.Linear(embDim + entityDim, 2)

    @classmethod
    def create(
        cls,
        embDim: int,
        outDim: int,
        hiddenDim: int,
        *,
        dropouts: Tuple[float, float] = (0.0, 0.0),
        entityDim: int,
        attentionNumHeads: int = 1,
        attentionDropout: float = 0.0,
        **kwargs: Any,
    ) -> 'EntityMhaAttention2MLP':
        del kwargs
        return cls(
            embDim=embDim,
            outDim=outDim,
            hiddenDim=hiddenDim,
            entityDim=entityDim,
            attentionNumHeads=attentionNumHeads,
            attentionDropout=attentionDropout,
            dropouts=dropouts,
        )

    def forward(self, x: Mapping[str, torch.Tensor]) -> torch.Tensor:
        article = x['article_embeddings']
        entities = x['entity_embeddings']
        entity_mask = x['entity_mask']
        pooled_entities, _ = self._compute_attention_pool(
            article=article,
            entities=entities,
            entity_mask=entity_mask,
        )
        norm_article = self.article_norm(article)
        norm_entities = self.entity_norm(pooled_entities)
        fusion_input = torch.cat((norm_article, norm_entities), dim=1)
        
        fusion_weights = torch.softmax(self.fusion_gate(fusion_input), dim=1)
        article_weight = fusion_weights[:, 0].unsqueeze(-1)
        entity_weight = fusion_weights[:, 1].unsqueeze(-1)
        weighted_article = norm_article * article_weight
        weighted_entities = norm_entities * entity_weight
        combined = torch.cat((weighted_article, weighted_entities), dim=1)
        return self.linear_relu_stack(combined)




def _resolve_output_layer(*, nn_model: nn.Module) -> nn.Linear:
    """Return final classification linear layer for known MLP variants."""
    if isinstance(
        nn_model,
        (
            MLP,
            MLPGELU,
            EntityAttentionMLP,
            EntityAttention2MLP,
            EntityMhaAttentionMLP,
            EntityMhaAttention2MLP,
        ),
    ):
        layer = nn_model.linear_relu_stack[-1]
    elif isinstance(nn_model, LeakyMLP):
        layer = nn_model.linear_leaky_relu_stack[-1]
    elif isinstance(nn_model, SkipMLP):
        layer = nn_model.finalLinear
    else:
        raise ValueError(f'Unsupported model type for output-bias initialization: {type(nn_model).__name__}')
    if not isinstance(layer, nn.Linear):
        raise ValueError(f'Output layer is not nn.Linear: {type(layer).__name__}')
    if layer.bias is None:
        raise ValueError('Output layer bias is None and cannot be initialized.')
    return layer


def _init_bias_from_prior(*, nn_model: nn.Module, bias_from_prior_logits: Sequence[float] | None) -> None:
    """Initialize output-layer bias from per-class logits."""
    if bias_from_prior_logits is None:
        return
    output_layer = _resolve_output_layer(nn_model=nn_model)
    bias_values = torch.as_tensor(
        bias_from_prior_logits,
        dtype=output_layer.bias.dtype,
        device=output_layer.bias.device,
    )
    if bias_values.ndim != 1:
        raise ValueError(f'Output bias logits must be a 1D sequence, got ndim={bias_values.ndim}.')
    if int(bias_values.shape[0]) != int(output_layer.out_features):
        raise ValueError(
            f'Output bias logits size mismatch: expected {output_layer.out_features}, got {bias_values.shape[0]}.',
        )
    with torch.no_grad():
        output_layer.bias.copy_(bias_values)


class NeuralCategModel(TextFromAnalysisModel[LabelT], SaveLoad):
    """
    Categorization model based on multi-layer perceptron neural network.
    """

    DEFAULT_BATCH_SIZE = 64

    def __init__(self, *,
            nnModel: nn.Module,
            catList: Iterable[LabelT] = None,
            textVectorizer: Vectorizer[str] = None,
            device=None
    ) -> None:
        if device is None:
            device = detectTorchDevice()
            LOG.info(f'Using {device} device')
        self._device = device
        self._nn = nnModel.to(device)
        self.catList = list(catList) if catList is not None else None
        self.textVectorizer = textVectorizer

    @classmethod
    def create(cls,
            embDim: int,
            outDim: int,
            *,
            hiddenDim: int = 512,
            dropouts: Tuple[float, ...] = None,
            nnType: Type[MLPNN] = None,
            catList: Iterable[LabelT] = None,
            textVectorizer: Vectorizer[str] = None,
            device=None,
            nnKwargs: Mapping[str, Any] | None = None,
            biasFromPriorLogits: Sequence[float] | None = None,
    ) -> 'NeuralCategModel':
        """
        Create an untrained model. Use train() subsequently to train the model.
        :param embDim: embedding dimension
        :param outDim: output dimension (should be equal to number of categories)
        :param hiddenDim: size of the hidden layer
        :param dropouts: tuple of dropout ratios 1. after embedding 2. after hidden layer
        :param nnType: neural network architecture; subclass of MLPNN
        :param catList: list of categories that will be predicted
        :param textVectorizer: vectorizer used to get embeddings of predicted text
        :param device: torch device (cpu/cuda)
        :return: untrained model instance
        """
        if dropouts is None:
            LOG.info('Dropouts not specified, using default (0.1, 0.3)')
            dropouts = (0.1, 0.3)

        if nnType is None:
            nnType = MLP

        if textVectorizer is None:
            LOG.info('Text vectorizer not specified, using default')
            textVectorizer = defaultEmbedTextVectorizer()

        if nnKwargs is None:
            nnKwargs = {}

        nn_model = nnType.create(
            embDim,
            outDim,
            hiddenDim,
            dropouts=dropouts,
            **dict(nnKwargs),
        )
        _init_bias_from_prior(nn_model=nn_model, bias_from_prior_logits=biasFromPriorLogits)
        return cls(
            nnModel=nn_model,
            catList=catList,
            device=device,
            textVectorizer=textVectorizer
        )

    def train(self,
            trainData: EmbeddingDataset,
            *,
            epochs: int,
            devData: EmbeddingDataset = None,
            batchSize: int = DEFAULT_BATCH_SIZE,
            lr: float = 0.001,
            optimizerFactory: Callable[[ParamsT, float], torch.optim.Optimizer] = None,
            lrSchedFactory: Callable[[torch.optim.Optimizer], torch.optim.lr_scheduler.LRScheduler] = None
    ) -> None:
        """
        Train the model on given data
        :param trainData: training dataset
        :param epochs: number of training epochs
        :param devData: optional development (validation) data
        :param batchSize: batch size
        :param lr: learning rate
        :param optimizerFactory: optimizer factory - a function which takes NN parameters and learning rate
            as an argument and returns an Optimizer. If None provided, Adam will be used.
        :param lrSchedFactory: learning rate scheduler factory - a function which takes an optimizer as an
            argument and returns a LRScheduler. If None provided, learning rate will remain fixed during training.
        """
        lossFn = torch.nn.BCEWithLogitsLoss()
        if optimizerFactory is not None:
            optimizer = optimizerFactory(self._nn.parameters(), lr)
        else:
            optimizer = torch.optim.Adam(self._nn.parameters(), lr=lr)

        self.catList = list(trainData.catList)

        train_collate = getattr(trainData, 'collate_fn', None)
        trainDataloader = DataLoader(
            trainData, batch_size=batchSize, shuffle=True, drop_last=True, collate_fn=train_collate,
        )
        if devData:
            dev_collate = getattr(devData, 'collate_fn', None)
            devDataloader = DataLoader(devData, batch_size=batchSize, collate_fn=dev_collate)

        lrSched = lrSchedFactory(optimizer) if lrSchedFactory else None

        for t in range(epochs):
            LOG.info(f"Epoch {t+1}\n-------------------------------")
            self._trainEpoch(trainDataloader, lossFn, optimizer, lrSched)
            if devData:
                self.validation(devDataloader, lossFn)
        self._nn.eval()

    def _trainEpoch(self, dataloader, lossFn, optimizer, lrSched=None) -> None:
        # single training epoch
        self._nn.train()
        size = len(dataloader.dataset)
        for batchNo, (X, y) in enumerate(dataloader):
            X = _batch_to_device(X, device=self._device)
            y = y.to(self._device)
            # Compute prediction and loss
            pred = self._nn(X)
            loss = lossFn(pred, y)

            # Backpropagation
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if batchNo % 100 == 0:
                batch_size = int(y.shape[0])
                loss, current = loss.item(), batchNo * batch_size
                LOG.info(f'loss: {loss:>7f}  [{current:>5d}/{size:>5d}]')
        if lrSched:
            lrSched.step()

    def predictText(self, text: str, *, thr: float = 0.0) -> WghLabels:
        """
        Predict scored labels for given text. Text embeddings will be computed using EmbeddingDataset's
        default EmbeddingFactory.
        :param text: input text
        :param thr: score threshold (default is 0.0)
        :return: scored labels for given text
        """
        return self.predictTextBatch([text], thr=thr)[0]

    def predictTextBatch(self, texts: Sequence[str], *, thr: float = 0.0) -> List[WghLabels]:
        """
        Predict scored labels for given texts. Text embeddings will be computed using EmbeddingDataset's
        default EmbeddingFactory.
        :param texts: input texts
        :param thr: score threshold (default is 0.0)
        :return: scored labels for given texts
        """
        return self.classifyTexts(texts=texts, thr=thr, returnScores=True, sigmoidScores=True)

    def classifyDataset(self,
            data: EmbeddingDataset,
            thr: float = None,
            returnScores: bool = False,
            sigmoidScores: bool = True
    ) -> Union[List[List[LabelT]], List[WghLabels]]:
        """
        Predict (optionally scored) labels for given EmbeddingDataset.
        :param data: input dataset
        :param thr: score threshold (default is 0.0 for logits and 0.5 for sigmoid)
        :param returnScores: if True, scores will be returned along with predicted labels
        :param sigmoidScores: if True, scores will be guaranteed to be in the interval [0, 1]
        :return: labels (optionally scored based on `returnScores`)
        """
        if thr is None:
            thr = 0.5 if sigmoidScores else 0.0
        sigmoid = torch.nn.Sigmoid() if sigmoidScores else None

        result = []
        self._nn.eval()
        collate_fn = getattr(data, 'collate_fn', None)
        with torch.no_grad():
            for X, _ in DataLoader(data, batch_size=self.DEFAULT_BATCH_SIZE, collate_fn=collate_fn):
                result.extend(self._classifyBatchMatrix(
                    X, thr=thr, returnScores=returnScores, sigmoidScores=sigmoidScores, sigmoid=sigmoid
                ))

        return result

    def classifyDocs(self,
            docs: Iterable[Doc],
            thr: float = None,
            returnScores: bool = False,
            sigmoidScores: bool = True,
            docVectorizer: Vectorizer[Doc] = None
    ) -> Union[List[List[LabelT]], List[WghLabels]]:
        """
        Predict (optionally scored) labels for given documents. Doc embeddings will be computed using
        EmbeddingDataset's default EmbeddingFactory.
        :param docs: input documents
        :param thr: score threshold (default is 0.0 for logits and 0.5 for sigmoid)
        :param returnScores: if True, scores will be returned along with predicted labels
        :param sigmoidScores: if True, scores will be guaranteed to be in the interval [0, 1]
        :param docVectorizer: optional document vectorizer. It can be useful if there is a vectorizer with advanced
             handling of document sections (title, lead, body) as opposed to model's default vectorizer
             which just concatenates document sections by double newline and uses a text vectorizer.
        :return: labels (optionally scored based on `returnScores`)
        """
        return self.classifyDataset(
            EmbeddingDataset.fromCorpus(Corpus(docs), vectorizer=docVectorizer or self._docVectorizer),
            thr=thr,
            returnScores=returnScores,
            sigmoidScores=sigmoidScores,
        )

    def classifyTexts(self,
            texts: Iterable[str],
            thr: float = None,
            returnScores: bool = False,
            sigmoidScores: bool = True
    ) -> Union[List[List[LabelT]], List[WghLabels]]:
        """
        Predict (optionally scored) labels for given texts. Texts embeddings will be computed using
        EmbeddingDataset's default EmbeddingFactory.
        :param texts: input texts
        :param thr: score threshold (default is 0.0 for logits and 0.5 for sigmoid)
        :param returnScores: if True, scores will be returned along with predicted labels
        :param sigmoidScores: if True, scores will be guaranteed to be in the interval [0, 1]
        :return: labels (optionally scored based on `returnScores`) as a list of lists
        """
        return self.classifyDocs(
            docs=[Doc.of(id=str(i), text=txt) for i, txt in enumerate(texts)],
            thr=thr,
            returnScores=returnScores,
            sigmoidScores=sigmoidScores,
            docVectorizer=self._docVectorizer
        )

    def classifyMatrix(self,
            embedMatrix: np.ndarray,
            thr: float = None,
            returnScores: bool = False,
            sigmoidScores: bool = True
    ) -> Union[List[List[LabelT]], List[WghLabels]]:
        """
        Classify given embedding matrix
        :param embedMatrix: matrix (num of docs) x (embedding dim)
        :param thr: score threshold (default is 0.0 for logits and 0.5 for sigmoid)
        :param returnScores: if True, scores will be returned along with predicted labels
        :param sigmoidScores: if True, scores will be guaranteed to be in the interval [0, 1]
        :return: labels (optionally scored based on `returnScores`) as a list of lists
        """
        if thr is None:
            thr = 0.5 if sigmoidScores else 0.0
        sigmoid = torch.nn.Sigmoid() if sigmoidScores else None

        result = []

        self._nn.eval()
        with torch.no_grad():
            for i in range(0, embedMatrix.shape[0], self.DEFAULT_BATCH_SIZE):
                result.extend(self._classifyBatchMatrix(
                    torch.from_numpy(embedMatrix[i: i + self.DEFAULT_BATCH_SIZE]),
                    thr=thr, returnScores=returnScores,
                    sigmoidScores=sigmoidScores, sigmoid=sigmoid
                ))

        return result

    def _predictMatrix(self, embedMatrix: torch.Tensor) -> torch.Tensor:
        """
        :param embedMatrix: matrix [doc count, embedding dim]
        :return: raw prediction matrix [doc count, category count]
        """
        with torch.no_grad():
            return self._nn(_batch_to_device(embedMatrix, device=self._device))

    def _classifyBatchMatrix(self,
            X: Any,
            thr: float,
            returnScores: bool,
            sigmoidScores: bool,
            sigmoid: torch.nn.Sigmoid
    ) -> Union[List[List[LabelT]], List[WghLabels]]:
        result = []
        pred = self._nn(_batch_to_device(X, device=self._device))
        if sigmoidScores:
            pred = sigmoid(pred)
        for i in range(pred.shape[0]):
            if returnScores:
                scoredCats = vecToScoredCats(pred[i].cpu().numpy(), self.catList, thr=thr)
                result.append(sorted(scoredCats, key=itemgetter(1), reverse=True))
            else:
                result.append(vecToCats(pred[i], self.catList, thr=thr))

        return result

    def validation(self, dataloader, lossFn, thr=0.0) -> None:
        # During training, compute and report metrics on validation dataset
        total_samples = 0
        total_gold = 0
        total_pred = 0

        num_batches = len(dataloader)
        test_loss, total_correct = 0, 0

        with torch.no_grad():
            self._nn.eval()
            for X, y in dataloader:
                X = _batch_to_device(X, device=self._device)
                y = y.to(self._device)
                pred = self._nn(X)
                test_loss += lossFn(pred, y).item()
                pred_cnt = (pred > thr).type(torch.float).sum().item()
                gold_cnt = (y > 0.5).type(torch.float).sum().item()
                correct = torch.logical_and(pred > thr, y > 0.5).type(torch.float).sum().item()
                total_correct += correct
                total_pred += pred_cnt
                total_gold += gold_cnt

                total_samples += X.shape[0]

        test_loss /= num_batches

        precision = total_correct / (total_pred or 1.0)
        recall = total_correct / total_gold

        LOG.info('Test Error: \n'
            f'Prec: {(100* precision):>0.2f}% ({total_correct}/{total_pred}), '
            f'Recall: {(100* recall):>0.2f}% ({total_correct}/{total_gold}), '
            f'Avg loss: {test_loss:>8f} \n'
        )

    def getInternalEmbeds(self, *, texts: Sequence[str] = None, dataset: EmbeddingDataset = None) -> torch.Tensor:
        """
        Return output of the hidden layer - that can be used as document embeddings
        which are close to each other for topically similar documents.
        :param texts: input texts
        :param dataset: input dataset with precomputed embeddings
        :return: output of the hidden layer
        """
        if dataset:
            inputVecs = dataset.X
        elif texts:
            inputVecs = self.textVectorizer.toMatrix(texts)
        else:
            raise ValueError('Either texts or dataset has to be provided')
        with torch.no_grad():
            return self._nn.linear_relu_stack[:3](inputVecs)

    @property
    def textVectorizer(self) -> Vectorizer[str]:
        return self._textVectorizer

    @property
    def docVectorizer(self) -> Vectorizer[Doc]:
        return self._docVectorizer

    @textVectorizer.setter
    def textVectorizer(self, v: Vectorizer[str]) -> None:
        """
        Set text vectorizer (which also sets internal doc vectorizer as wrapper of `v`)
        :param v: text vectorizer
        """
        self._textVectorizer = v
        self._docVectorizer = DocVectorizer.fromTextVectorizer(self._textVectorizer)

    # Override SaveLoad._save_specials
    def _save_specials(self, fname, separately, sep_limit, ignore, pickle_protocol, compress, subname):
        torch.save(self._nn, subname(fname, '_nn'))
        return super()._save_specials(
            fname, separately, sep_limit, {'_nn', '_device'}, pickle_protocol, compress, subname
        )

    # Override SaveLoad._load_specials
    # Load model into GPU if available
    def _load_specials(self, fname, mmap, compress, subname):
        super()._load_specials(fname, mmap, compress, subname)
        self._device = detectTorchDevice()
        self._nn = torch.load(subname(fname, '_nn'), map_location=self._device, weights_only=False)

    def __repr__(self) -> str:
        return (f'{self.__class__.__qualname__}'
                f'(nn={self._nn!r}, catList={self.catList!r}, textVectorizer={self.textVectorizer!r})')
