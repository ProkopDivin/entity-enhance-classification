'''
Minimal SPARQL endpoint client for Wikidata description fetching.
'''

import requests


class UrlSparqlService:
    '''
    Execute SPARQL SELECT queries against a remote endpoint.
    '''

    def __init__(self, url: str) -> None:
        self.url = url
        self.session = requests.Session()

    def query(self, query: str) -> dict:
        '''
        Run a SPARQL query and return parsed JSON results.

        :param query: SPARQL query string
        :return: Parsed JSON response body
        '''
        resp = self.session.post(
            self.url,
            data={'query': query},
            headers={'Accept': 'application/sparql-results+json'},
            timeout=(3.05, 60),
        )
        resp.raise_for_status()
        return resp.json()
