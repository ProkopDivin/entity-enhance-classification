"""
Embedrest client used by SvcTextVectorizer.
"""

import base64
from itertools import islice
from typing import Iterable, Mapping, Sequence, Union

import numpy as np
import requests

Paragraph = Sequence[str]
Doc = Sequence[Paragraph]

DEFAULT_SENTS_BATCH_SIZE = 512
DEFAULT_DOCS_BATCH_SIZE = 4


def _slice_stream(stream: Iterable, batch_size: int) -> Iterable[list]:
    while True:
        batch = list(islice(stream, batch_size))
        if not batch:
            break
        yield batch


class Client:
    """
    Embedding service (embedrest) client.
    """

    DOCS_ENDPOINT = 'docs'
    SENTS_ENDPOINT = 'sentences'

    TIMEOUT_CFG = (3.05, 16)

    def __init__(self, *, url: str, sentenceModelId: str, docModelId: str) -> None:
        self.url = url
        self.sentenceModelId = sentenceModelId
        self.docModelId = docModelId
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json; charset=utf-8',
            'Accept': 'application/json; charset=utf-8'
        })

    @classmethod
    def create(cls, *, url: str, sentenceModelId: str = None, docModelId: str = None) -> 'Client':
        return cls(url=url, sentenceModelId=sentenceModelId, docModelId=docModelId)

    def embedDocsIter(
            self,
            *,
            texts: Iterable[str] = None,
            structs: Iterable[Doc] = None,
            normalize: bool = False,
            batchSize: int = DEFAULT_DOCS_BATCH_SIZE
    ) -> Iterable[np.ndarray]:
        if structs is not None:
            inputs = structs
            reqInputFld = 'structs'
        elif texts is not None:
            inputs = texts
            reqInputFld = 'texts'
        else:
            raise ValueError('Neither texts nor tokenized documents provided')

        yield from self._embedDocBatchIter(reqInputFld, inputs=inputs, normalize=normalize, batchSize=batchSize)

    def _embedDocBatchIter(self, reqFld: str, inputs: Iterable[Union[str, Doc]], normalize: bool, batchSize: int):
        for docBatch in _slice_stream(inputs, batchSize):
            reqDict = {
                reqFld: docBatch,
                'normalize': normalize
            }
            if self.docModelId:
                reqDict['model_id'] = self.docModelId

            resp = self._extractResp(
                self.session.post(url=f'{self.url}/{self.DOCS_ENDPOINT}', json=reqDict, timeout=self.TIMEOUT_CFG)
            )
            yield respToMatrix(resp)

    def _extractResp(self, resp):
        resp.raise_for_status()
        respDict = None
        try:
            respDict = resp.json()
        except Exception:
            pass

        if respDict is None or 'emb' not in respDict:
            raise ValueError('Unexpected response: ' + resp.text)

        return respDict

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.session.close()


def respToMatrix(resp: Mapping) -> np.ndarray:
    matrix = np.frombuffer(base64.b64decode(resp['emb']), dtype=resp['dtype'])
    matrix.resize(resp['nrows'], resp['ncols'])
    return matrix
